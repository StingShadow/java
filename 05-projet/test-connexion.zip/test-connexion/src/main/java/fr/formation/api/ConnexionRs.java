package fr.formation.api;

import javax.inject.Singleton;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import fr.formation.model.User;

@Singleton
@Path("/connexion")
public class ConnexionRs {

	@Context
	private HttpServletRequest httpRequest;
	

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public String connexion(User user) {
		httpRequest.getSession().setAttribute("user", user);
		System.out.println("ID de " + ((User) httpRequest.getSession().getAttribute("user")).getLogin()  + " : "  + httpRequest.getSession().getId());
		return user.getLogin();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public User test() {
		return (User) httpRequest.getSession().getAttribute("user");
		
	}
	
	@GET
	@Path("/deconnexion")
	@Produces(MediaType.APPLICATION_JSON)
	public void deconnexion() {
		httpRequest.getSession().setAttribute("user", null);
		httpRequest.getSession().invalidate();
	}
	

	@POST
	@Path("/couleur/{coul}")
	public void couleur(@PathParam("coul") String couleur) {
		httpRequest.getSession().setAttribute("couleur", couleur);
		System.out.println("couleur pr�f�r�e de " + ((User) httpRequest.getSession().getAttribute("user")).getLogin()  + " : " + couleur);
		
	}
	@GET
	@Path("/couleur")
	public String couleur() {
		return (String) httpRequest.getSession().getAttribute("couleur");
		
	}

}
