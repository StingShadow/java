package fr.formation.util;

import fr.formation.exception.OperationException;

public class Operation {

	public static int addition(int a, int b) {
		return a + b;
	}

	public static int soustraction(int a, int b) {
		return a - b;
	}

	public static double division(int a, int b) throws OperationException {
		if (b == 0) {
			OperationException oe = new OperationException("Division par z�ro");
			throw oe;
		}
		return a / b;
	}

	public static int multiplication(int a, int b) {
		return a * b;
	}
}
