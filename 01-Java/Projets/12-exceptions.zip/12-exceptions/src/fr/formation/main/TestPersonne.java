package fr.formation.main;

import fr.formation.exception.PersonneException;
import fr.formation.model.Personne;

public class TestPersonne {
	public static void main(String[] args) {
		
		Personne p1 = null;
		try {
			p1 = new Personne("Legrand", "Jules", 66);
		} catch (PersonneException e) {
			System.out.println("Probleme lors de la creation de personne : " + e.getMessage());
		}
		System.out.println("p1 : "  + p1);
		
		try {
			p1.setAge(67);
		} catch (PersonneException e1) {
			System.out.println("Probleme lors de la modification de l'age ");
		}
		System.out.println("p1 avec modif age (1) : "  + p1);
		
		try {
			p1.setAge(-1);
		} catch (PersonneException e1) {
			System.out.println("Probleme lors de la modification de l'age ");
		}
		System.out.println("p1 avec modif age (2) : "  + p1);
		
		Personne p2 = null;
		try {
			p2 = new Personne("Legrand", null, 66);
		} catch (PersonneException e) {
			System.out.println("Probleme lors de la creation de personne : " + e.getMessage());

		}
		System.out.println("p2 : "  + p2);
	}
}
