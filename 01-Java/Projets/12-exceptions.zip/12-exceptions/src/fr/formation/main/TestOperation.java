package fr.formation.main;

import fr.formation.exception.OperationException;
import fr.formation.util.Operation;

public class TestOperation {

	public static void main(String[] args) {
		
		System.out.println("5 + 3 = " + Operation.addition(5, 3));
		
		try {
			System.out.println("81 / 3 = " + Operation.division(81, 3));
		} catch (OperationException e1) {
			System.out.println("Probleme lors de l'appel � division (1) : " + e1.getMessage());
		}
		
		
		try {
			System.out.println("81 / 0 = " + Operation.division(81, 0));
		} catch (OperationException e1) {
			System.out.println("Probleme lors de l'appel � division (2) : " + e1.getMessage());
		}

		String chaine =  "ABC";
		
		try {
			System.out.println("Taille de chaine : " + chaine.length());
			int[] tabEntiers = {1,2,3,4};
			System.out.println("Le quatrieme element est : " + tabEntiers[3]);
			int a = 0 / 0;
		}
		catch(NullPointerException npe) {
			System.out.println("Ouch, probleme avec chaine");
		}
		catch(ArrayIndexOutOfBoundsException ae) {
			System.out.println("Ouch, probleme avec le tableau");
		}
		catch(Exception e) {
			System.out.println("Ouch, probleme non pr�vu ...");
		}
		
		
		
		
		System.out.println("FIN DU PROGRAMME");
	}

}
