package fr.formation.model;

import fr.formation.exception.PersonneException;

public class Personne {

	private String nom;
	private String prenom;
	private int age;

	public Personne(String nom, String prenom, int age) throws PersonneException {
		setNom(nom);
		setPrenom(prenom);
		setAge(age);
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) throws PersonneException {
		if (nom == null || nom.equals(""))
			throw new PersonneException("Le nom n'est pas correct");
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) throws PersonneException {
		if (prenom == null || prenom.equals(""))
			throw new PersonneException("Le prenom n'est pas correct");
		this.prenom = prenom;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) throws PersonneException {
		if (age <= 0)
			throw new PersonneException("L'age n'est pas correct");
		this.age = age;
	}

	@Override
	public String toString() {
		return "Personne [nom=" + nom + ", prenom=" + prenom + ", age=" + age + "]";
	}

}
