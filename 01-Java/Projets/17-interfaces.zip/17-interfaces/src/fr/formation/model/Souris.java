package fr.formation.model;

public class Souris extends Proie {

	public Souris(String nom) {
		super(nom);
	}


	@Override
	public String toString() {
		return "Souris [nom=" + super.getNom() + "]";
	}
}
