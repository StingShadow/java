package fr.formation.model;

public class Chat extends Animal implements Predateur, Savant{


	public Chat(String nom) {
		super(nom);
	}

	@Override
	public String toString() {
		return "Chat [nom=" + super.getNom() + "]";
	}
	
	@Override
	public void chasser(Proie p) {
		System.out.println(getNom() + " se camoufle et epie " + p.getNom());
	}
	
	@Override
	public void comprendre(String phrase) {
		System.out.println(getNom() + " comprend " + phrase + " mais s'en fiche");
	}
}
