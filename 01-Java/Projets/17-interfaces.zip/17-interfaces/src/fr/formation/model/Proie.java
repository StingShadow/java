package fr.formation.model;

public abstract class Proie extends Animal {

	public Proie(String nom) {
		super(nom);
	}


	@Override
	public String toString() {
		return "Proie [nom=" + super.getNom() + "]";
	}
}
