package fr.formation.model;

public interface Predateur {

	void chasser (Proie p);
}
