package fr.formation.model;

public class TRex extends Animal implements Predateur{

	public TRex(String nom) {
		super(nom);
	}
	
	@Override
	public String toString() {
		return "TRex [nom=" + super.getNom() + "]";
	}
	
	@Override
	public void chasser (Proie p) {
		System.out.println(getNom() + " dechiquete " + p.getNom());
	}
}
