package fr.formation.model;

public class Biche extends Proie {

	public Biche(String nom) {
		super(nom);
	}
	
	@Override
	public String toString() {
		return "Biche [nom=" + super.getNom() + "]";
	}
}
