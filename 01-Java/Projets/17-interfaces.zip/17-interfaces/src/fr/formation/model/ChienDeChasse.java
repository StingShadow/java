package fr.formation.model;

public class ChienDeChasse extends Chien implements Predateur{

	public ChienDeChasse(String nom) {
		super(nom);
	}

	@Override
	public void chasser(Proie p) {
		System.out.println(getNom() + " obeit avant de chasser");
		
	}

	@Override
	public String toString() {
		return "ChienDeChasse [nom=" + super.getNom() + "]";
	}
}
