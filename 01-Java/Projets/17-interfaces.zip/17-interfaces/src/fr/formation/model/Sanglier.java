package fr.formation.model;

public class Sanglier extends Proie {

	public Sanglier(String nom) {
		super(nom);
	}
	
	@Override
	public String toString() {
		return "Sanglier [nom=" + super.getNom() + "]";
	}
}
