package fr.formation.model;

public class Chien extends Animal implements Savant{


	public Chien(String nom) {
		super(nom);
	}


	@Override
	public String toString() {
		return "Chien [nom=" + super.getNom() + "]";
	}
	
	@Override
	public void comprendre (String phrase) {
		System.out.println(getNom() + " comprend " + phrase + " et me fait la fête");
	}
	
}
