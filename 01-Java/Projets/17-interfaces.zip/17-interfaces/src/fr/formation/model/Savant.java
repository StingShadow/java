package fr.formation.model;

public interface Savant {

	void comprendre(String phrase);
}
