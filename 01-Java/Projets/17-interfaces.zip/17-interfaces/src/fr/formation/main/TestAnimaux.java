package fr.formation.main;

import fr.formation.model.Animal;
import fr.formation.model.Biche;
import fr.formation.model.Chat;
import fr.formation.model.Chien;
import fr.formation.model.ChienDeChasse;
import fr.formation.model.Predateur;
import fr.formation.model.Proie;
import fr.formation.model.Sanglier;
import fr.formation.model.Savant;
import fr.formation.model.Souris;
import fr.formation.model.TRex;

public class TestAnimaux {

	public static void main(String[] args) {
		Chien chien1= new Chien("Rantanplan");
		Chat chat1 = new Chat("Minou");
		Souris souris1 = new Souris("Speedy Gonzales");
		TRex trex1 = new TRex("Rex");
		Biche biche1 = new Biche("Bambi");
		ChienDeChasse cdc1 = new ChienDeChasse("Beethoven");
		Sanglier san1 = new Sanglier("Poumba");
		
		System.out.println(chien1);
		chien1.comprendre("A table !");
		System.out.println(chat1);
		chat1.chasser(souris1);
		chat1.comprendre("Viens ici !");
		System.out.println(trex1);
		trex1.chasser(biche1);
		System.out.println(cdc1);
		cdc1.comprendre("Viens ici");
		cdc1.chasser(san1);
		
		
		Animal[] animaux = new Animal[7];
		animaux[0] = chien1;
		animaux[1] = chat1;
		animaux[2] = souris1;
		animaux[3] = trex1;
		animaux[4] = biche1;
		animaux[5] = cdc1;
		animaux[6] = san1;
		
		System.out.println("\nTous les animaux: ");
		for (Animal a : animaux) {
			System.out.println(a);
		}
		
		Predateur[] predateurs = new Predateur[3];
		predateurs[0] = chat1;
		predateurs[1] = trex1;
		predateurs[2] = cdc1;
		
		
		System.out.println("\nTous les prédateurs: ");
		for (Predateur p : predateurs) {
			System.out.println(p);
		}

		System.out.println("\nTous les savants: ");
		for (Animal a : animaux) {
			if (a instanceof Savant)
				System.out.println(a);
		}

		System.out.println("\nToutes les proies: ");
		for (Animal a : animaux) {
			if (a instanceof Proie)
				System.out.println(a);
		}

	}

}
