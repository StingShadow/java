package fr.formation.groupeeleves.exception;


public class ClasseException extends Exception {

	public ClasseException(String message) {
		super(message);
	}

}
