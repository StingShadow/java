package fr.formation.groupeeleves.model;

import java.util.Date;

public class Parent extends Personne{

	public Parent() {
		super();
	}

	public Parent(String nom, String prenom, String adresse, Date ddn) {
		super(nom, prenom, adresse, ddn);
	}
		
}
