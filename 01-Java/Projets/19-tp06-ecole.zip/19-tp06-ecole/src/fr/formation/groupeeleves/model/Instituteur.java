package fr.formation.groupeeleves.model;

import java.util.Date;

public class Instituteur extends Personne{

	public Instituteur() {
		super();
	}

	public Instituteur(String nom, String prenom, String adresse, Date ddn) {
		super(nom, prenom, adresse, ddn);
	}
	
}
