package fr.formation.groupeeleves.model;

import fr.formation.groupeeleves.exception.ClasseException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Classe {
    private String nom;
    private Instituteur instituteur;
    private List<Eleve> lstEleves;

    public Classe() {
    	this(null);
    }

    public Classe(String nom) {
        this.nom = nom;
        lstEleves = new ArrayList<>();
        instituteur = null;
    }

    public void addEleve(Eleve e) {
        this.lstEleves.add(e);
    }

    public void removeEleve(Eleve e) {
        this.lstEleves.remove(e);
    }

    public Eleve getEleve(Integer i) throws ClasseException {
        Eleve e;
        try {
            e = this.lstEleves.get(i);
        } catch (IndexOutOfBoundsException e1) {
            throw new ClasseException("La classe ne contient que " + this.lstEleves.size() + "eleves");
        }
        return e;
    }

    public void sortListEleve() {
        Collections.sort(this.lstEleves);
    }

    public List<Eleve> getLstEleves() {
        return lstEleves;
    }

    public void setLstEleves(List<Eleve> lstEleves) {
    	if (lstEleves != null)
    		this.lstEleves = lstEleves;
    	else
    		this.lstEleves = new ArrayList<Eleve>();
    }

    public List<Parent> getListParent() {
        List<Parent> result = new ArrayList<>();
        for (Eleve eleve : lstEleves) {
            if (eleve.getReferent() != null && !result.contains(eleve.getReferent())) {
                result.add(eleve.getReferent());
            }
        }
        return result;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Instituteur getInstituteur() {
        return instituteur;
    }

    public void setInstituteur(Instituteur instituteur) {
        this.instituteur = instituteur;
    }

    public String toString() {
        StringBuffer result = new StringBuffer();
        result.append("---------------------------------------------------").append("\n");
        result.append("Classe : ").append(this.nom).append("\n");
        result.append("   Instituteur : ").append(this.instituteur.getPrenom()).append(" ")
                .append(this.instituteur.getNom()).append("\n");
        result.append("     avec :").append("\n");
        for (Eleve eleve : lstEleves) {
            result.append("     ").append(eleve.getPrenom()).append(" ").append(eleve.getNom()).append("\n");
        }
        result.append("---------------------------------------------------");
        return result.toString();
    }
}
