package fr.formation;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TestWhile {

	public static void main(String[] args) {
		int valeur = 412;
		Scanner sc = new Scanner(System.in);
		
		do {
			System.out.println("Veuillez entrer un nombre entre 1 et 10");
			try {
				valeur = sc.nextInt();
			}
			catch(InputMismatchException e) {
				sc.nextLine();
				valeur = -1;
			}
		}
		while(valeur < 1 || valeur > 10);
		
		sc.close();
	}

}
