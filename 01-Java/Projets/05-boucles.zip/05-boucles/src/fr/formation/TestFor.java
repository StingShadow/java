package fr.formation;

public class TestFor {

	public static void main(String[] args) {
		
		for(int cpt = 0 ; cpt < 10 ; cpt++) {
			System.out.println(cpt + 1);
		}
		
		
		int i = 0;
		
		for( ; ; ) {
			System.out.println(i + 1);
			i++;
			if (i == 10)
				break;
		}

	}
}
