package fr.formation.model;

import java.time.LocalDate;

public class Personne {

	private String nom;
	private String prenom;
	private int age;
	private LocalDate dateDeNaissance;
	
	
	public Personne() {
		
		System.out.println("Dans le constructeur de Personne");
	}
	
	
	public Personne(String nom, String prenom, LocalDate dateDeNaissance) {
		this.setNom(nom);
		this.setPrenom(prenom);
		this.setDateDeNaissance(dateDeNaissance);
	}


	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public LocalDate getDateDeNaissance() {
		return dateDeNaissance;
	}

	public void setDateDeNaissance(LocalDate dateDeNaissance) {
		this.dateDeNaissance = dateDeNaissance;
	}

	public void quiEsTu() {
		System.out.println("Je suis " + this.prenom + 
				" " + this.nom +  " et j'ai " +
				this.getAge() + " ans et je suis n� le " +
				this.dateDeNaissance);
	}
	
	public int getAge() {
		if (this.dateDeNaissance == null)
			return 0;
		
		return LocalDate.now().getYear() - 
				this.dateDeNaissance.getYear();
	}


	public String toString() {
		return "Personne [nom=" + nom + ", prenom=" + prenom + ", age=" + age + ", dateDeNaissance=" + dateDeNaissance
				+ "]";
	}
	
	
	
	
	
	
}
