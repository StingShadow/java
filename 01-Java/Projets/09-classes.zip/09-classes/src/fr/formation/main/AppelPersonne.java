package fr.formation.main;

import java.time.LocalDate;

import fr.formation.model.Personne;

public class AppelPersonne {

	public static void main(String[] args) {
		
		Personne p1 = new Personne();
		System.out.println(p1);
		
		Personne p2 = new Personne();
		System.out.println(p2);

		// mettre un nom � p1
		p1.setNom("Dupond");
		p1.setPrenom("Lolo");
//		p1.age = 35;
		p1.setDateDeNaissance(LocalDate.now());
		
		p1.quiEsTu();

		p2.quiEsTu();
		
		
		Personne p3 = new Personne("Leblond", "Suzon", LocalDate.of(1926, 2, 14));
		p3.quiEsTu();
		System.out.println(p3.toString());
		
		
		Personne p4 = new Personne("Lebrun", "Suzanne", LocalDate.of(2032, 2, 14));
		p4.setNom(null);
		p4.quiEsTu();
	}

}
