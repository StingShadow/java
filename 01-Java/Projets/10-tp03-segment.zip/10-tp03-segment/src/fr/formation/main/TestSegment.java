package fr.formation.main;

import fr.formation.model.Segment;

public class TestSegment {

	public static void main(String[] args) {
		Segment s1 = new Segment(24, 12);
		System.out.println(s1.toString());
		System.out.println("Longueur de s1 = " + s1.getLongueur());
		boolean ok = s1.contient(15);
//		if (ok)
//			System.out.println("15 appartient au segment : vrai");
//		else
//			System.out.println("15 appartient au segment : faux");
			
		System.out.println("15 appartient au segment : " + (ok ? "VRAI" : "FAUX"));
		ok = s1.contient(152);
		System.out.println("152 appartient au segment : " + (ok ? "VRAI" : "FAUX"));
	
		s1.ordonne();
		System.out.println("Longueur de s1 = " + s1.getLongueur());
		System.out.println(s1.toString());
	}
	
	private void testQuiSertARien() {
		int a = 2;
		int b;
		if (a == 2)
			b = 3;
		else
			b = 9;
		
		b = (a == 2) ? 3 : 9;
	}
	
	
}
