package fr.formation.model;

public class Segment {
	private int extr1;
	private int extr2;
		
	public Segment(int extr1, int extr2) {
		this.extr1 = extr1;
		this.extr2 = extr2;
	}
	
	public void ordonne() {
		if (extr1 > extr2) {
			int temp = extr1;
			extr1 = extr2;
			extr2 = temp;
		}
	}
	
	public int getLongueur() {
		int longueur = Math.abs(extr2 - extr1);
		return longueur;
	}
	
	public boolean contient(int x) {
		return (x >= Math.min(extr1, extr2) && x <= Math.max(extr1, extr2));
	}

	public String toString() {
		return "SEGMENT[" + extr1 + "," + extr2 + "]";
	}
	
	
}
