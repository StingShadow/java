package fr.formation.model;

import java.time.LocalDate;

public class Stagiaire extends Personne {

	private LocalDate dateInscription ;
	
	public Stagiaire() {
		super();
		dateInscription = LocalDate.of(2020, 1, 1);
		System.out.println(" (creation d'un stagiaire)");
	}

	public Stagiaire(String nom, String prenom, LocalDate dateDeNaissance, LocalDate dateInscription) {
		// Appeler le constructeur de Personne avec les 3 parametres
		super(nom, prenom, dateDeNaissance);
		this.dateInscription = dateInscription;
		System.out.println(" (creation d'un stagiaire avec tous les parametres)");

	}
	
	
	
	
	@Override
	// Outrepassage
	// Pas une surcharge
	public void presenteToi() {
		System.out.println("Je m'appelle " + prenom + " " + nom + " et je suis né(e) le " + 
				dateDeNaissance + " et je suis inscrit depuis le " + this.dateInscription);
	}

	
}
