package fr.formation.model;

public class Stagiaire extends Personne {

	public Stagiaire() {
		System.out.println(" (creation d'un stagiaire)");
	}
}
