package fr.formation.model;

import java.time.LocalDate;

public class Formateur extends Personne {

	private String specialite;
	
	public Formateur() {
		super();
		specialite = "Java - Spring";
	}

	public Formateur(String nom, String prenom, LocalDate dateDeNaissance, String specialite) {
		super(nom, prenom, dateDeNaissance);
		this.specialite = specialite;
	}

	@Override
	public void presenteToi() {
		System.out.println("Je m'appelle " + prenom + " " + nom + " et je suis né(e) le " + 
				dateDeNaissance + " et ma specialité est " + this.specialite);
	}

	public String getSpecialite() {
		return specialite;
	}

	public void setSpecialite(String specialite) {
		this.specialite = specialite;
	}
	
	

}
