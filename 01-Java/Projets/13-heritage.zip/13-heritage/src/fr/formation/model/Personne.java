package fr.formation.model;

import java.time.LocalDate;

public class Personne {

	protected String nom;
	protected String prenom;
	protected LocalDate dateDeNaissance;
	
	public Personne() {
		this.prenom = "Bob";
		this.nom = "Marley";
		this.dateDeNaissance = LocalDate.of(1945, 2, 6);
	}
	
	
	public Personne(String nom, String prenom, LocalDate dateDeNaissance) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.dateDeNaissance = dateDeNaissance;
	}


	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public LocalDate getDateDeNaissance() {
		return dateDeNaissance;
	}
	public void setDateDeNaissance(LocalDate dateDeNaissance) {
		this.dateDeNaissance = dateDeNaissance;
	}
	
	
	public void presenteToi() {
		System.out.println("Je m'appelle " + prenom + " " + nom + " et je suis né(e) le " + dateDeNaissance);
	}
	
	// Surcharge de la methode presenteToi()
	public void presenteToi(String langue) {
		if ("anglais".equals(langue))
			System.out.println("My name is " + prenom + " " + nom + " and I was born " + dateDeNaissance);
		else
			presenteToi();
	}
	
}
