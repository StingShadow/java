package fr.formation.main;

import java.time.LocalDate;

import fr.formation.model.Formateur;
import fr.formation.model.Personne;
import fr.formation.model.Stagiaire;

public class TestPersonnes {

	public static void main(String[] args) {
		
		// Personnes
		Personne p1 = new Personne();
		p1.presenteToi();
		
		Personne p2 = new Personne("Lechatain", "Lulu", LocalDate.of(2000, 1, 14));
		p2.presenteToi();
		p2.presenteToi("anglais");
		p2.presenteToi("espagnol");
		p2.presenteToi(null);
		
		// Stagiaires
		Stagiaire s1 = new Stagiaire();
		s1.presenteToi();
		
		System.out.println("Nom de s1 : " + s1.getNom());
		
		Stagiaire s2 = new Stagiaire("Lebleu", "Joe", LocalDate.of(1984, 11, 4), LocalDate.of(2021, 3, 4));
		s2.presenteToi();
		s2.presenteToi("anglais");
		
		// Formateurs
		Formateur f1 = new Formateur();
		f1.presenteToi();
		
		Formateur f2 = new Formateur("Levert", "Romeo", LocalDate.of(1969, 8, 8), "PHP");
		f2.presenteToi();
		
		// Tableaux
		Stagiaire[] listeStagiaires = new Stagiaire[2];
		listeStagiaires[0] = s1;
		listeStagiaires[1] = s2;
		
		System.out.println("\nListe des stagiaires");
		for (Stagiaire s : listeStagiaires) {
			s.presenteToi();
		}
		
		Formateur[] listeFormateurs = new Formateur[2];
		listeFormateurs[0] = f1;
		listeFormateurs[1] = f2;
		System.out.println("\nListe des formateurs");
		for (Formateur f : listeFormateurs) {
			f.presenteToi();
		}
		
		System.out.println("\nListe des personnes");
		Personne[] listePersonnes = new Personne[6];
		listePersonnes[0] = p1;
		listePersonnes[1] = p2;
		listePersonnes[2] = s1;
		listePersonnes[3] = s2;
		listePersonnes[4] = f1;
		listePersonnes[5] = f2;
		
		for (Personne p : listePersonnes) {
			p.presenteToi();
		}
		
		System.out.println("\nSpecialité de formateurs de la liste des personnes");
		for (Personne p : listePersonnes) {
			if (p instanceof Formateur) {
				String spec = ((Formateur) p).getSpecialite();
				System.out.println(spec);
			}
		}
	
		System.out.println("\nListe des stagiaires de la liste des personnes");
		for (Personne p : listePersonnes) {
			if (p instanceof Stagiaire) {
				p.presenteToi();
			}
		}

		System.out.println("\nListe des personnes de la liste des personnes");
		for (Personne p : listePersonnes) {
			if (p.getClass() == Personne.class) {
				p.presenteToi();
			}
		}
		
		
	}
}
