package fr.formation.main;

import java.time.LocalDate;

import fr.formation.model.Personne;
import fr.formation.model.Stagiaire;

public class TestPersonnes {

	public static void main(String[] args) {
		Personne p1 = new Personne();
		p1.presenteToi();
		
		Personne p2 = new Personne("Lechatain", "Lulu", LocalDate.of(2000, 1, 14));
		p2.presenteToi();
		
		
		Stagiaire s1 = new Stagiaire();
		s1.presenteToi();
	}
}
