package fr.formation;

public class Variables {
	public static void main(String[] args) {

		int entier = 12;
		boolean monTest = true;
		long entierLong = 0;
		
		if (monTest) {
			entierLong = 100;
			
			System.out.println("entier = " + entier);
		}
		
		System.out.println("entierLong = " + entierLong);
		System.out.println("entier = " + entier);

		
	}
}
