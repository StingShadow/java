package fr.formation;

import java.util.Iterator;

public class Entiers {

	public static void main(String[] args) {
		
		byte byte1 = 4;
//		byte byte2 = 400;
//		short short1 = byte1 + 0;
		int int1 = byte1 + 0;
		
		long l1 = 0L;
		int int2 = (int) l1;  // cast explicite
		
		long l2 = int1 ;		// cast implicite
		
		float float1 = (float) 3.14; // cast explicite
		float float2 = 3.14f ;
		
		boolean b1 = float2 > float1 & l2 == l1;
		
		boolean b2    = (float2 > float1) &  (l2 == l1);
		boolean b2bis = (float2 > float1) && (l2 == l1);
		boolean b3    = (float2 > float1) |  (l2 == l1);
		boolean b3bis = (float2 > float1) || (l2 == l1);
		
		String chaine1 = null;
		String chaine2 = "abcdef";
		
		if (chaine2 != null & chaine2.length() > 2) {
			System.out.println("Chaine2 a plus de 2 caracteres");
		}
		
		if (chaine1 != null && chaine1.length() > 2) {
			System.out.println("Chaine1 a plus de 2 caracteres");
		}
		
		char car1 = 'a';
		char car2 = ' ';
		char car3 = 'b';
		
		System.out.println(car1 + car2 + car3);
		
		char car4 = '\t';
		char car5 = '\u20BF';
		System.out.println(car5);
	}
}
