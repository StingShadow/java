package fr.formation;

public class Manipulations {

	public static void main(String[] args) {
		int a = 4;
		int b = 3;
		
		double d1 = a / b;
		double d1bis = (double) (a / b);
		
		System.out.println("d1 = " + d1);

		double d2 = (double) a / b ;
		System.out.println("d2 = " + d2);

		
		int i1 = Integer.MAX_VALUE;
		System.out.println("i = " + i1);
		System.out.println("i1 + 10 = " + (i1 + 10));
		
		
		a = a + b;
		a += b;
		
		a = a + 1;
		a += 1;
		a++;
		++a;
		
		
	}

}
