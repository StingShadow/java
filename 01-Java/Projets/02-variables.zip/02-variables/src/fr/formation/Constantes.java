package fr.formation;

public class Constantes {
	public static void main(String[] args) {
		
		final double PI = 3.1415;
		// PI = 3.14;
		final long mille = (long) 1e3;
		System.out.println(mille);
	}
}
