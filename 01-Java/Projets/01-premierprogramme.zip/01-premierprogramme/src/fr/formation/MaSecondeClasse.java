package fr.formation;

/**
 * 
 * @author Administrateur
 * Ma classe permet de bien travailler
 */


public class MaSecondeClasse {

	/**
	 * Ceci est la m�thode main    
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Hello");
		int titi = 4;
		int toto;
		toto = 4;
		
		int tata = 0;
		
		if (titi == 4) {
			tata = 12;
		}
		else {
			
		}
		
		if (tata == 3) {
			
		}
	}
 // Jusqu'� la fin de la ligne
	
	
/*
	public static void main(String[] args) {
		System.out.println("Hello");
	}
*/
}
