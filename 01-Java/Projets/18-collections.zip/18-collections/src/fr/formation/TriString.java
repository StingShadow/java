package fr.formation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TriString {
	public static void main(String[] args) {
		
		List<String> listeS = new ArrayList<String>();
		
		listeS.add("a");
		listeS.add("H");
		listeS.add(" ");
		listeS.add(",");
		listeS.add("b");
		listeS.add("z");
		listeS.add("y");
		
		Collections.sort(listeS);
		for (String string : listeS) {
			System.out.println(string);
		}
	}
}
