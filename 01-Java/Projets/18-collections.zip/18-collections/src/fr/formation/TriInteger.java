package fr.formation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TriInteger {

	public static void main(String[] args) {
		
		List<Integer> listeI = new ArrayList<Integer>();
		listeI.add(45);
		listeI.add(-8);
		listeI.add(0);
		listeI.add(1);
		listeI.add(-3);
		listeI.add(99);
		listeI.add(-44);
		listeI.add(22);
		listeI.add(21);
		listeI.add(-11);
		
		System.out.println("\nListe non triée : ");
		for (Integer integer : listeI) {
			System.out.println(integer);
		}
		
		Collections.sort(listeI);
		System.out.println("\nListe triée : ");
		for (Integer integer : listeI) {
			System.out.println(integer);
		}
		
		Collections.sort(listeI, Collections.reverseOrder());
		System.out.println("\nListe triée dans l'ordre inverse: ");
		for (Integer integer : listeI) {
			System.out.println(integer);
		}
		
		
		
	}
}
