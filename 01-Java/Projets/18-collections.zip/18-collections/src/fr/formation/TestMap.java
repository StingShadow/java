package fr.formation;

import java.util.HashMap;
import java.util.Map;

public class TestMap {

	public static void main(String[] args) {
		// Exemple Département : 44 -> "Loire-Atlantique"
		// K : Key , V : Value
		Map<Integer, String> bretagne = new HashMap<Integer, String>();
		
		bretagne.put(29, "Finistere");
		bretagne.put(22, "Côtes d'Armor");
		bretagne.put(56, "Morbihan");
		bretagne.put(35, "Ile et Vilaine");
		bretagne.put(44, "Loire-Atlantique");
		
		System.out.println("56 : " + bretagne.get(56));
		System.out.println("86 : " + bretagne.get(86));
		
		Map<Integer, String> alsace = new HashMap<Integer, String>();
		alsace.put(67, "Bas-Rhin");
		alsace.put(68, "Haut-Rhin");
		
		System.out.println("67 : " + alsace.get(67));
		
		// Exemple Région : "bzh" -> bretagne, "als" -> alsace
		Map<String, Map<Integer, String>> france = new HashMap<String, Map<Integer,String>>();
		france.put("bzh", bretagne);
		france.put("als", alsace);
		
		
		System.out.println("44 (Bretagne) : " + france.get("bzh").get(44));
		
	}
}
