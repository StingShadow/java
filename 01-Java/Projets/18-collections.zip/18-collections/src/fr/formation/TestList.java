package fr.formation;

import java.util.ArrayList;
import java.util.List;

import fr.formation.model.Personne;

public class TestList {

	public static void main(String[] args) {
		
		ArrayList<Object> listeObj = new ArrayList<>();
		listeObj.add("Bonjour");
		listeObj.add(4);
		listeObj.add(true);
		listeObj.add(null);
		listeObj.add(null);
		
		System.out.println("Nb elements dans listeObj : " + listeObj.size());
		
		for (Object o : listeObj) {
			System.out.println(o);
		}
		
		
		ArrayList<Integer> listeEntiers = new ArrayList<Integer>();
		listeEntiers.add(87);
		listeEntiers.add(-87);
		listeEntiers.add(0);
		
		
		System.out.println("\nNb elements dans listeEntiers : " + listeEntiers.size());
		
		for (Integer i : listeEntiers) {
			System.out.println(i);
		}
		
		System.out.println("\n2eme element de listeEntiers : " + listeEntiers.get(1));
		listeEntiers.remove(1);
		

		System.out.println("\nNb elements dans listeEntiers : " + listeEntiers.size());
		
		for (Integer i : listeEntiers) {
			System.out.println(i);
		}
		
		listeEntiers.add(1, 41);

		System.out.println("\nNb elements dans listeEntiers : " + listeEntiers.size());
		
		for (Integer i : listeEntiers) {
			System.out.println(i);
		}

		List<Personne> listeP = new ArrayList<Personne>();
		
		Personne p1 = new Personne("Lechene", "Rene", 44);
		Personne p2 = new Personne("Leboulot", "Joe", 66);
		Personne p3 = new Personne("Lechataignier", "Aline", 55);
		
		listeP.add(p1);
		listeP.add(p2);
		listeP.add(p3);

		System.out.println("\nNb elements dans listeP : " + listeP.size());
		
		for (Personne p : listeP) {
			System.out.println(p);
		}

		listeP.remove(0);

		System.out.println("\nNb elements dans listeP apres supp de 0: " + listeP.size());
		
		for (Personne p : listeP) {
			System.out.println(p);
		}

		listeP.remove(p3);

		System.out.println("\nNb elements dans listeP apres supp de p3: " + listeP.size());
		
		for (Personne p : listeP) {
			System.out.println(p);
		}


		
	}
}
