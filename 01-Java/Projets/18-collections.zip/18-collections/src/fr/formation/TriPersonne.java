package fr.formation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import fr.formation.model.Personne;

public class TriPersonne {
	public static void main(String[] args) {

		List<Personne> listeP = new ArrayList<Personne>();
		Personne p1 = new Personne("Legrand", "Ludovic", 45);
		Personne p2 = new Personne("Lepetit", "Marie", 14);
		Personne p3 = new Personne("Lemoyen", "Suzon", 78);
		Personne p4 = new Personne("Letresgrand", "Jack", 51);
		Personne p5 = new Personne("Albert", "Simone", 74);
		Personne p6 = new Personne("Zoe", "Arthur", 61);
		Personne p7 = new Personne("Lemoyen", "Joe", 19);
		Personne p8 = new Personne("Lemoyen", "Suzon", 49);
		listeP.add(p1); listeP.add(p2); listeP.add(p3); listeP.add(p4);
        listeP.add(p5); listeP.add(p6); listeP.add(p7); listeP.add(p8);
        
        System.out.println("\nListe des personnes : ");
        for (Personne personne : listeP) {
			System.out.println(personne);
		}
        
        Collections.sort(listeP);
        
        System.out.println("\nListe des personnes triee par age asc : ");
        for (Personne personne : listeP) {
			System.out.println(personne);
		}
     // LA SUITE A VOIR ULTERIEUREMENT EN DETAIL
        
        Collections.sort(listeP, new Comparator<Personne>() {

			@Override
			public int compare(Personne o1, Personne o2) {
				return o1.getPrenom().compareTo(o2.getPrenom());
			}
		});
        
        System.out.println("\nListe des personnes triee par prenom asc : ");
        for (Personne personne : listeP) {
			System.out.println(personne);
		}
        
        
        Collections.sort(listeP, (pp1, pp2) -> pp1.getAge() - pp2.getAge());
        System.out.println("\nListe des personnes triee par age asc : ");
        for (Personne personne : listeP) {
			System.out.println(personne);
		}
	}
}
