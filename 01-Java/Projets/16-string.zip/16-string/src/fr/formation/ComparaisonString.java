package fr.formation;

public class ComparaisonString {

	public static void main(String[] args) {
		
		String chaine = "";
		long debut = System.currentTimeMillis(); // nb de ms depuis le 01/01/1970
		
		for (int i = 0 ; i < 500000 ; i++) {
			chaine += "a";
		}
		long fin = System.currentTimeMillis();
		System.out.println("duree concatenation String : " + (fin - debut) + "ms");
		
		
		StringBuilder sb = new StringBuilder();
		debut = System.currentTimeMillis();
		for (int i = 0 ; i < 500000 ; i++) {
			sb.append("a");
		}
		fin = System.currentTimeMillis();
		System.out.println("duree concatenation StringBuilder : " + (fin - debut) + "ms");
	}

}
