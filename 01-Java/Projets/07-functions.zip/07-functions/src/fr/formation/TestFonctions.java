package fr.formation;

public class TestFonctions {

	public static void main(String[] args) {
		
		bonjour();
		bonjour();
		bonjour();
		
		hello("Legrand");
		hello("Lepetit");
		
		int res = addition(8, 16);
		System.out.println("8 + 16 = " + res);
		
		String chaine = null;
		try {
			int var = 0 / 0;
			int nbCar = chaine.length();
		} catch (Exception e) {
			System.out.println("Une exception est survenue : " + e.getMessage());
		}
		
	}
	
	
	private static void bonjour() {
		System.out.println("bonjour");
	}

	
	private static void hello(String nom) {
		System.out.println("Hello " + nom);
	}
	
	private static int addition(int a, int b) {
		int resultat = a + b;
		return resultat;
	}
}
