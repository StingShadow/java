package fr.formation.main;

import fr.formation.forme.Carre;
import fr.formation.forme.Cercle;
import fr.formation.forme.FigureGeometrique;
import fr.formation.forme.Rectangle;

public class TestFormes {

	public static void main(String[] args) {
		
		Rectangle r1 = new Rectangle(50, 20, "rouge");
		System.out.println(r1.toString());
		System.out.println("perimetre de r1 : " + r1.getPerimetre());
		System.out.println("aire de r1 : " + r1.getAire());
		
		Carre c1 = new Carre(100, "vert");
		System.out.println(c1.toString());
		System.out.println("perimetre de c1 : " + c1.getPerimetre());
		System.out.println("aire de c1 : " + c1.getAire());
		
		Cercle ce1 = new Cercle(100, "bleu");
		System.out.println(ce1);
		System.out.println("perimetre de ce1 : " + ce1.getPerimetre());
		System.out.println("aire de ce1 : " + ce1.getAire());
		
	//	FigureGeometrique fg = new FigureGeometrique("jaune");
		
		FigureGeometrique fg1 = new Carre(20, "bleu pale");
		FigureGeometrique fg2 = new Rectangle(20, 15, "vert pale");
		FigureGeometrique fg3 = new Cercle(1, "rouge pale");
		
		FigureGeometrique[] mesFigGeo = new FigureGeometrique[3];
		mesFigGeo[0] = fg1;
		mesFigGeo[1] = fg2;
		mesFigGeo[2] = fg3;
		System.out.println("\nListe des FG");
		for (FigureGeometrique fg : mesFigGeo) {
			System.out.println(fg.toString());
			System.out.println("Perimetre : " + fg.getPerimetre());
			System.out.println("Aire : " + fg.getAire());
			System.out.println();
		}
	}

}
