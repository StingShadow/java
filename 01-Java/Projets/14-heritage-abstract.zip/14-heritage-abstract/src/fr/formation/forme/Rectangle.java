package fr.formation.forme;

public class Rectangle extends FigureGeometrique{
	
	private double longueur;
	private double largeur;

	public Rectangle(double longueur, double largeur, String couleur) {
		super(couleur);
		this.longueur = longueur;
		this.largeur = largeur;
	}
	
	@Override
	public double getAire() {
		return this.longueur * this.largeur;
	}
	
	@Override
	public double getPerimetre() {
		return 2 * (longueur + largeur);
	}
	

	public double getLongueur() {
		return longueur;
	}

	public double getLargeur() {
		return largeur;
	}

	@Override
	public String toString() {
		return "Rectangle [longueur=" + longueur + ", largeur=" + largeur + ", couleur=" + getCouleur() + "]";
	}
	
	

}
