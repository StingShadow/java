package fr.formation.forme;

public class Carre extends Rectangle {

	public Carre(double cote, String couleur) {
		super(cote, cote, couleur);
	}
	
	

	@Override
	public String toString() {
		return "Carre [cote=" + super.getLargeur() + ", couleur=" + getCouleur() + "]";
	}
}
