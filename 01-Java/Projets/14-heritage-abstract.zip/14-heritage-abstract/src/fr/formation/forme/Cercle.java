package fr.formation.forme;

public class Cercle extends FigureGeometrique {

	private double rayon;
	
	public Cercle(double rayon, String couleur) {
		super(couleur);
		this.rayon = rayon;
	}
	
	@Override
	public double getPerimetre() {
		return Math.PI * 2.0 * this.rayon;
	}
	
	@Override
	public double getAire() {
		return Math.PI * this.rayon * this.rayon;
	}

	@Override
	public String toString() {
		return "Cercle [rayon=" + rayon + ", couleur=" + getCouleur() + "]";
	}
	
	
}
