package fr.formation.forme;

abstract public class FigureGeometrique {

	private String couleur;
	
	public FigureGeometrique(String couleur) {
		this.couleur = couleur;
	}

	public String getCouleur() {
		return couleur;
	}

	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}
	

	abstract public double getPerimetre();
	
	abstract public double getAire();
	
}
