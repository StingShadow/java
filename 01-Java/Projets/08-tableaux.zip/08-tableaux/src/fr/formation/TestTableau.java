package fr.formation;

public class TestTableau {

	public static void main(String[] args) {

		String[] tabChaines = new String[3];

		tabChaines[0] = "Zero";
		tabChaines[1] = "Un";
		tabChaines[2] = "Deux";
//		tabChaines[3] = "Trois";

		for (int i = 0; i < tabChaines.length; i++) {
			System.out.println(i + " : " + tabChaines[i]);
		}

		for (String chaine : tabChaines) {
			System.out.println(chaine);
		}

		int tab2Dim[][] = new int[4][5];
		int nb = tab2Dim.length;
		System.out.println(nb);

		int[] montab = tab2Dim[0];
		nb = montab.length;
		System.out.println(nb);

		tab2Dim[2][3] = 6;
		
		int []tabPasCarre[] = new int[4][];
		tabPasCarre[0] = new int[4];
		tabPasCarre[1] = new int[1];
		tabPasCarre[2] = new int[1];
		tabPasCarre[3] = new int[1];
		
		int[] t1, t2[];
		
		
		Double d1 = new Double(5.2);
		Double d2 = Double.valueOf(5.2);
		Double d3 = 5.2; 
		
		double tp1 = d2;
		
		
		
	}

}
