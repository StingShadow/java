/**
 * 
 */
package com.formation.commande.modele.bo;


/**
 * 
 *
 */
public class Stylo extends Article {
	private String couleur;
	
	public Stylo (String marque, String ref, String designation, float pu, int qte, String couleur) {

		setMarque(marque);

		setReference(ref);

		setDesignation(designation);

		setPrixUnitaire(pu);

		setQteStock(qte);

		setCouleur(couleur);
		
	}
	
	public Stylo (String marque, String ref, String designation, float pu, String couleur) {
		this(marque, ref, designation, pu, 0, couleur);
	}

	/**
	 * @return the couleur
	 */
	public final String getCouleur() {
		return couleur;
	}

	/**
	 * @param couleur the couleur to set
	 * 
	 */
	public final void setCouleur(String couleur) {
		if (couleur == null || couleur.trim().length() == 0)
			return;
		this.couleur = couleur;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(super.toString());
		builder.append(" ");
		builder.append("Stylo [");
		if (couleur != null) {
			builder.append("couleur=");
			builder.append(getCouleur());
		}
		builder.append("]");
		return builder.toString();
	}

  	
}
