/**
 * 
 */
package com.formation.commande.modele.bo;



/**
 * 
 * Le panier stocke les articles selectionnes par l'utilisateur au cours de 
 * sa navigation. Le panier n'est pas sauvegarde.
 */
public class Panier {
    private float montant;

    private LignePanier[] lignesPanier;
    private int indexLigne;

	
    public Panier(){
    	lignesPanier = new LignePanier[20];
    	indexLigne = 0;
    }
    /**
	 * @return the montant
	 */
	public final float getMontant() {
		montant = 0;
		for (LignePanier ligne : lignesPanier) {
			if (ligne != null)
				montant += ligne.getPrix();
			else break;
		}
		return montant;
	}
	
	/**
	 * @return the lignesPanier
	 */
	public final LignePanier[] getLignesPanier() {
		return lignesPanier;
	}

	
	/**
     * Ajouter une ligne au panier. Le prix de la ligne est calcule (Qte*prix)
     * @param numero
     * @param article
     * @param qte
     * 
     */
    public void addLigne(Article article, int qte) {
		
		//si assez d'articles en stock, on ajoute au panier
    	if (article.getQteStock() >= qte) {
    		lignesPanier[indexLigne] = new LignePanier(article, qte);
    		indexLigne++; 
    	}
    }

    
    public final LignePanier getLigne(int index) {
		
 		return lignesPanier[index];
     }

    
    /**
     * Presenter le detail du panier
     */
    @Override
    public String toString() {
		StringBuffer bf =new StringBuffer();
		int index = 0;
		bf.append("Panier : \n\n");
		for (LignePanier ligne : lignesPanier) {
			if (ligne != null){
				bf.append("ligne " + index + " :\t");
				bf.append(ligne.toString());
				bf.append("\n");
			} else break;
			index++;
		}
		bf.append("\nValeur du panier : " + getMontant());
		bf.append("\n\n");
		return bf.toString();
    }
    
    
    /**
     * Modifier la quantite placee dans le panier dans les limites du stock virtuel de l'article
     * La quantite en stock augmente ou diminue en fonction de cette nouvelle qte
     * @param index
     * @param newQte
     * 
     */
    public void updateLigne(int index, int newQte) {
		if (index <= this.lignesPanier.length-1) {
			if (lignesPanier[index].getQte() > newQte)
				//l'ancienne quantite est superieure a la nouvelle. On augmente le stock virtuel de la difference
				lignesPanier[index].getArticle().entrerStock(lignesPanier[index].getQte()-newQte);
			else if (lignesPanier[index].getQte() < newQte) {
				//l'ancienne quantite est inferieure a la nouvelle
				if (lignesPanier[index].getArticle().getQteStock() >= newQte - lignesPanier[index].getQte()){
					//et le stock virtuel est suffisant. On diminue le stock virtuel de la difference
					lignesPanier[index].getArticle().sortirStock(newQte - lignesPanier[index].getQte());
				} else {
					//sinon on sort sans mise a jour du panier
					return;
				}
			}
			//la quantite de la ligne est mise a jour
			lignesPanier[index].setQte(newQte);
		}
    }   

}
