/**
 * 
 */
package com.formation.commande.modele.bo;


public abstract class Article {
	private String reference;
	private String marque;
	private String designation;
	private float prixUnitaire;
	private int qteStock;
	
	
	/**
	 * @return the marque
	 */
	public final String getMarque() {
		return marque;
	}

	/**
	 * @param marque the marque to set
	 *  
	 */
	protected final void setMarque(String marque) {
		if (marque == null || marque.trim().length() == 0)
			return;
		this.marque = marque;
	}

	/**
	 * @return the reference
	 */
	public final String getReference() {
		return reference;
	}

	/**
	 * @param reference the reference to set
	 *  
	 */
	protected final void setReference(String reference) {
		if (reference == null || reference.trim().length() == 0)
			return;
		this.reference = reference;
	}

	/**
	 * @return the designation
	 */
	public final String getDesignation() {
		return designation;
	}

	/**
	 * @param designation the designation to set
	 *  
	 */
	public final void setDesignation(String designation) {
		if (designation == null || designation.trim().length() == 0)
			return;
		this.designation = designation;
	}

	/**
	 * @return the prixUnitaire
	 */
	public final float getPrixUnitaire() {
		return prixUnitaire;
	}

	/**
	 * @param prixUnitaire the prixUnitaire to set
	 *  
	 */
	public final void setPrixUnitaire(float prixUnitaire) {
		if (prixUnitaire <= 0.0)
			return;
		this.prixUnitaire = prixUnitaire;
	}

	/**
	 * @return the qteStock
	 */
	public final int getQteStock() {
		return qteStock;
	}

	/**
	 * @param qteStock the qteStock to set
	 */
	public final void setQteStock(int qteStock) {
		if (qteStock <= 0)
			return;
		this.qteStock = qteStock;
	}

	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Article [");
		if (marque != null) {
			builder.append("marque=");
			builder.append(getMarque());
			builder.append(", ");
		}
		if (reference != null) {
			builder.append("reference=");
			builder.append(getReference());
			builder.append(", ");
		}
		if (designation != null) {
			builder.append("designation=");
			builder.append(getDesignation());
			builder.append(", ");
		}
		builder.append("prixUnitaire=");
		builder.append(getPrixUnitaire());
		builder.append(", qteStock=");
		builder.append(getQteStock());
		builder.append("]");
		return builder.toString();
	}
	    
 	/**
 	 * ajouter une quantite dans le stock virtuel de cet article
 	 * @param qte
 	 */
    protected void entrerStock(int qte) {
    	if (qte <= 0)
    		return;
  		qteStock += qte;
  	}

  	/**
  	 * supprimer une quantite dans le stock virtuel de cet article
  	 * @param qte
  	 * 
  	 */
    protected void sortirStock(int qte) {
  		if (qte > this.qteStock)
  			return;
  		else
  			qteStock -= qte;
  	}
    
}
