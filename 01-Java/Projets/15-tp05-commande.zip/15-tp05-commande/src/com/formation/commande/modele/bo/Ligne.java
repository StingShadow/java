/**
 * 
 */
package com.formation.commande.modele.bo;

/**

 *
 */
public abstract class Ligne {
	protected int qte;
    protected float prix;
    private Article article;

    public Ligne(Article article, int qte) {
    	this.setArticle(article);
    	this.setQte(qte);
    }


	/**
	 * @return the qte
	 */
	public final int getQte() {
		return qte;
	}

	/**
	 * @param qte the qte to set
	 */
	protected void setQte(int qte) {
		this.qte = qte;
		//la quantite change, le prix aussi
		this.prix = article.getPrixUnitaire() * qte;
	}

	/**
	 * @return the prix
	 */
	public final float getPrix() {
		return prix;
	}


	/**
	 * @return the article
	 */
	public final Article getArticle() {
		return article;
	}

	/**
	 * @param article the article to set
	 */
	protected final void setArticle(Article article) {
		this.article = article;
	}



	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(", qte=");
		builder.append(getQte());
		builder.append(", prix=");
		builder.append(getPrix());
		builder.append(", ");
		if (article != null) {
			builder.append("article=");
			builder.append(getArticle().toString());
		}
		builder.append("]");
		return builder.toString();
	}

    

}
