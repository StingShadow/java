/**
 * 
 */
package com.formation.commande.modele.bo;


/**
 *
 *
 */
public class LignePanier extends Ligne {

    public LignePanier(Article article, int qte) {
    	super(article,qte);
    	//sortie de stock virtuel, la quantite en stock virtuel est mise a jour
    	article.sortirStock(qte);
    }
    
	/**
	 * @param qte the qte to set
	 */
	public final void setQte(int qte) {
		super.setQte(qte);
	}
	
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Ligne [");
		builder.append(super.toString());
		return builder.toString();
	}

}
