/**
 * 
 */
package com.formation.commande.modele.bo;



/**

 * Le catalogue represente la liste des articles extraits de la source de donnees
 * suite a une recherche lancee par l'utilisateur
 */
public class Catalogue {

    private Article[] articlesAuCatalogue;


    public Catalogue(Article[] articles){
    	articlesAuCatalogue = articles;
    }
    
    
//    public Article getArticle(int index) {
//    }


	/**
	 * @return the articlesAuCatalogue
	 */
	public final Article[] getArticlesAuCatalogue() {
		return articlesAuCatalogue;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Catalogue [");
		if (articlesAuCatalogue != null) {
			builder.append("articlesAuCatalogue=").append("\n");
			for (Article article : articlesAuCatalogue) {
				if (article != null)
					builder.append("\t").append(article.toString()).append("\n");
			}
			
		}
		builder.append("]");
		return builder.toString();
	}
	
    
}
