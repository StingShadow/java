/**
 * 
 */
package com.formation.commande.modele.bo;


/**
 *
 *
 */
public class Ramette extends Article {
	private int grammage;
		
	public Ramette (String marque, String ref, String designation, float pu, int grammage) {
		this(marque, ref, designation, pu, 0, grammage);
	}
	
	public Ramette (String marque, String ref, String designation, float pu, int qte, int grammage) {

		setMarque(marque);

		setReference(ref);

		setDesignation(designation);

		setPrixUnitaire(pu);

		setQteStock(qte);

		setGrammage(grammage);

	}

	/**
	 * @return the grammage
	 */
	public final int getGrammage() {
		return grammage;
	}

	/**
	 * @param grammage the grammage to set
	 * @throws ArgumentException 
	 */
	public final void setGrammage(int grammage) {
		if (grammage < 0.0)
			return;
		this.grammage = grammage;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(super.toString());
		builder.append(" ");
		builder.append("Ramette [grammage=");
		builder.append(getGrammage());
		builder.append("]");
		return builder.toString();
	}
 	
 	
}
