package fr.formation.model;

public class Cercle {

	private double rayon;
	private Point centre;
	
	public Cercle(Point centre, double rayon) {
		this.centre = centre;
		this.rayon = rayon;
	}
	
	public Cercle(Point centre, Point point) {
		this.centre = centre;
		rayon = distanceAuCentre(point);
	}
	
	public double getPerimetre() {
		return 2.0 * Math.PI * this.rayon;
		
	}

	public double getSurface() {
		return Math.PI * Math.pow(this.rayon, 2);
	}
	
	public boolean contient(Point point) {
		// si la distance entre le point et le centre est inferieur au rayon : OK
		// sinon pas OK
		double distance = distanceAuCentre(point);
		
//		if (distance <= rayon )
//			return true;
//		else 
//			return false;
		
		//  return (distance <= rayon ) ? true : false;
		
		return distance <= rayon;
	}

	private double distanceAuCentre(Point point) {
		double x = point.getX() - centre.getX();
		double y = point.getY() - centre.getY();
		double distance = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
		return distance;
	}
}
