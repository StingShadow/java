package fr.formation;

import java.util.Scanner;

public class TestSwitch {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Entrez une note entre 0 et 5");
		int note = sc.nextInt();
		
		switch(note) {
		case 0 : System.out.println("Film nul"); break;
		case 1 : System.out.println("Film pas terrible"); break;
		case 2 : System.out.println("Film tout juste moyen"); break;
		case 3 : System.out.println("Film pas mal"); break;
		case 4 : System.out.println("Film bien"); break;
		case 5 : System.out.println("CHEF D'OEUVRE !"); break;
		default : System.out.println("note entre 0 et 5 !");
		}

		
		sc.close();
	}
}
