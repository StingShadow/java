package fr.formation;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TestIf {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Votre nom : ");
		String nom = sc.nextLine(); // chaine de caracteres
		
		System.out.println("Votre age : ");

		try {
		
			int age = sc.nextInt();
			System.out.println("Bonjour " + nom + ", vous avez " + age + " ans" );
			
			if (age <= 0) {
				System.out.println("Pas bien !!!! On vous a dit d'entrer un entier positif !");
			}
			else {
				if (age < 18) {
					System.out.println("Vous �tes mineur");
				} else {
					if (age < 100) {
						System.out.println("Vous �tes majeur et dans la force de l'age");
					} else {
						System.out.println("Vous �tes centenaire");
					}
				}				
			}
		}
		catch(InputMismatchException e) {		
			System.out.println("Pas bien !!!! On vous a dit d'entrer un entier !");
			System.out.println("Il va falloir tout recommencer");
		}
		
		
		
		System.out.println("Fin du programme");
		sc.close();
	}

}
