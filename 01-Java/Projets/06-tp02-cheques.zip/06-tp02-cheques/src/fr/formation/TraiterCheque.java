package fr.formation;

import java.util.Scanner;

public class TraiterCheque {

    public static void main(String[] args) {
        // A faire
        int numero = 0;
        int numPetit = 0;
        int numGrand = 0;

        int nbTotal = 0;
        int nbInf200 = 0;
        int nbSup200 = 0;

        float montant = 0.0f; // => JVM va devoir convertir en m�moire l'entier en un float
        float montantTotal = 0.0f;
        float montantTotalInf200 = 0.0f;
        float montantTotalSup200 = 0.0f;

        float montantLePlusPetit = 0;
        float montantLePlusGrand = 0;

        Scanner scanner = new Scanner(System.in);

        do{
            System.out.println("Quel est le num�ro du ch�que ? (0 pour sortir)");
            numero = scanner.nextInt();

            // l'utilisateur a-t-il termin� la saisie ?
            if (numero == 0){
                // Affichage
                    if(nbTotal == 0){   // aucun cheque n'a �t� saisi
                        System.out.println("Aucun ch�que n'a �t� saisi !");
                    }
                    else{

                        System.out.println("Nombre de ch�ques : " + nbTotal);
                        System.out.println("Total de ch�ques : " + montantTotal);

                            // sp�cifiquement ici, pas besoin de d�claration d'une variable
                        System.out.println("Moyenne : " + montantTotal / nbTotal);

                        System.out.println("Nombre de ch�ques < 200 : " + nbInf200);
                        System.out.println("Total de ch�ques < 200 : " + montantTotalInf200);
                        System.out.println("Nombre de ch�ques >= 200 : " + nbSup200);
                        System.out.println("Total de ch�ques >= 200 : " + montantTotalSup200);

                        System.out.println("Num�ro cheque le plus petit : " + numPetit);
                        System.out.println("Montant cheque le plus petit : " + montantLePlusPetit);

                        System.out.println("Num�ro cheque le plus grand : " + numGrand);
                        System.out.println("Montant cheque le plus grand : " + montantLePlusGrand);

                    }

            }
            else{ // traitements
                System.out.println("Quel est le montant du cheque ?");
                montant = scanner.nextFloat();

                nbTotal++;
                montantTotal += montant;

                if (montant < 200){
                    nbInf200++;
                    montantTotalInf200 += montant;
                }
                else {   // cas ou montant >= 200
                    nbSup200++;
                    montantTotalSup200 += montant;
                }

                if(nbTotal == 1){
                    montantLePlusGrand = montant;
                    montantLePlusPetit = montant;
                    numPetit = numero;
                    numGrand = numero;
                }else{
                    if (montant < montantLePlusPetit){
                        montantLePlusPetit = montant;
                        numPetit = numero;
                    }

                    if(montant > montantLePlusGrand)
                    {
                        montantLePlusGrand = montant;
                        numGrand = numero;
                    }
                }
            }
        }
        while(numero != 0);

        scanner.close();
    }

}
