package fr.formation.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import fr.formation.entity.Berline;
import fr.formation.entity.Voiture;
import fr.formation.entity.VoitureAbstract;

public class SingleTable {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("monpu");
		EntityManager em = emf.createEntityManager();
		
		Voiture v = new Voiture("Peugeot");
		Berline b = new Berline("Mercedes", "Jaune");
		
		em.getTransaction().begin();
		try {
			em.persist(v);
			em.persist(b);
			em.getTransaction().commit();
		} catch (Exception e) {
			em.getTransaction().rollback();
			e.printStackTrace();
		}
		
		System.out.println("\nListe de toutes les voitures 'Voiture'");
		List<Voiture> listeV = em.createQuery("from Voiture v", Voiture.class).getResultList();
		listeV.forEach(voi -> System.out.println("   - " + voi));
		
		System.out.println("\nListe de toutes les voitures 'Berline'");
		List<Berline> listeB = em.createQuery("from Berline b", Berline.class).getResultList();
		listeB.forEach(voi -> System.out.println("   - " + voi));
		
		
		System.out.println("\nListe de toutes les voitures ");
		List<VoitureAbstract> listeA = em.createQuery("from VoitureAbstract a", VoitureAbstract.class).getResultList();
		listeA.forEach(voi -> System.out.println("   - " + voi));
		
		
		em.close();
		emf.close();
	}

}
