package fr.formation.main;

import java.util.ArrayList;
import java.util.List;

import fr.formation.dal.DaoUtil;
import fr.formation.dal.GroupeDao;
import fr.formation.entity.Album;
import fr.formation.entity.Groupe;

public class TestOTM {

	public static void main(String[] args) {
		Album a1 = new Album("The Dark Side Of The Moon", 1973);
		Album a2 = new Album("Wish You Where Here", 1975);
		Album a3 = new Album("The Wall", 1979);
		
		List<Album> liste1 = new ArrayList<Album>();
		liste1.add(a1);
		liste1.add(a2);
		liste1.add(a3);
		
		Groupe g1 = new Groupe("Pink Floyd", liste1);
		
		Album a4 = new Album("Led Zeppelin", 1969);
		Album a5 = new Album("Led Zeppelin II", 1969);
		Album a6 = new Album("Led Zeppelin III", 1970);
		Album a7 = new Album("Led Zeppelin IV", 1971);
		
		List<Album> liste2 = new ArrayList<Album>();
		liste2.add(a4);
		liste2.add(a5);
		liste2.add(a6);
		liste2.add(a7);
		
		Groupe g2 = new Groupe("Led Zeppelin", liste2);
		
		GroupeDao gDao = new GroupeDao();
		gDao.add(g1);
		gDao.add(g2);
		
		System.out.println("Groupe dont l'id est 2 : ");
		System.out.println(gDao.findById(2));
		
		System.out.println("Suppression de Pink Floyd");

		gDao.delete(g1);
		
		
		DaoUtil.close();
	}

}
