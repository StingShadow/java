package fr.formation.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import fr.formation.entity.Personne;
import fr.formation.entity.PersonnePrimaryKey;

public class TestCleComposite {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("monpu");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		Personne p1 = new Personne("Legrand", "Suzie", 44);
		Personne p2 = new Personne("Legrand", "Joe", 55);
		
		et.begin();
		try {
			em.persist(p1);
			em.persist(p2);
			et.commit();
		} catch (Exception e) {
			e.printStackTrace();
			et.rollback();
		}
		
		System.out.println("\nListe des personnes en base :");
		List<Personne> listeP = em.createQuery("from Personne p", Personne.class).getResultList();
		listeP.forEach(p -> System.out.println(p));
		
		
		PersonnePrimaryKey ppk = new PersonnePrimaryKey("Legrand", "Suzie");
		Personne trouve = em.find(Personne.class, ppk);
		System.out.println("\nPersonne dont le nom est Legrand et le prénom Suzie : " + trouve);
		
		
		ppk = new PersonnePrimaryKey("Legrand", "Joe");
		trouve = em.find(Personne.class, ppk);
		System.out.println("\nPersonne dont le nom est Legrand et le prénom Joe : " + trouve);
		
		ppk = new PersonnePrimaryKey("Legrand", "Zoe");
		trouve = em.find(Personne.class, ppk);
		System.out.println("\nPersonne dont le nom est Legrand et le prénom Zoe : " + trouve);
		
		em.close();
		emf.close();
	}

}
