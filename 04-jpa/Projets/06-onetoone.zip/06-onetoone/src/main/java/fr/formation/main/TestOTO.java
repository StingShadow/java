package fr.formation.main;

import java.util.List;

import fr.formation.dal.DaoUtil;
import fr.formation.dal.DepartementDao;
import fr.formation.entity.Departement;
import fr.formation.entity.Ville;

public class TestOTO {

	public static void main(String[] args) {
		DepartementDao dao = new DepartementDao();
		
		Ville v1 = new Ville("Nantes", 300000);
		Departement dep1 = new Departement("44", "Loire-Atlantique", v1);
		
		dao.add(dep1);

		Departement dep2 = new Departement("86", "Vienne", new Ville("Poitiers", 80000));
		dao.add(dep2);

		System.out.println("Liste des departements :");
		List<Departement> listeD = dao.findAll();
		listeD.forEach(d -> System.out.println("  - " + d));
		
		System.out.println("\nDepartement id = 1 : " + dao.findById(1));
		System.out.println("\nDepartement id = 7 : " + dao.findById(7));
		
		dep1.getPrefecture().setPopulation(310000);
		dao.update(dep1);
		
		Ville v2 = new Ville("Poitiers", 85000);
		dep2.setPrefecture(v2);
		dao.update(dep2);
		
		System.out.println("Suppression de dep1");
		dao.delete(dep1);
		
		
		DaoUtil.close();
	}

}
