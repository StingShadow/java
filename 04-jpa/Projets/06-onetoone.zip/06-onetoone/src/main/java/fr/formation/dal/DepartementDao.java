package fr.formation.dal;

import java.util.List;

import javax.persistence.EntityManager;

import fr.formation.entity.Departement;

public class DepartementDao {

	private EntityManager em;
	
	public DepartementDao() {
		em = DaoUtil.getEntityManager();
	}
	
	
	public void add(Departement dep) {
		em.getTransaction().begin();
		
		try {
			em.persist(dep);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
	
	public List<Departement> findAll(){
		return em
				.createQuery("Select d From Departement d", Departement.class)
				.getResultList();
	}
	
	public Departement findById(int id) {
		return em.find(Departement.class, id);
	}


	public void update(Departement dep) {
		em.getTransaction().begin();
		
		try {
			em.merge(dep);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
	
	
	public void delete(Departement dep) {
		em.getTransaction().begin();
		
		try {
			em.remove(dep);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
}
