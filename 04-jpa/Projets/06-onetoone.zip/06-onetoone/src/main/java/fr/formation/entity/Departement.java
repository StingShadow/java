package fr.formation.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "DeptOTO")
public class Departement {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String numero;
	private String nom;
	
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	private Ville prefecture;

	public Departement() {
	}

	
	
	public Departement(String numero, String nom, Ville prefecture) {
		this.numero = numero;
		this.nom = nom;
		this.prefecture = prefecture;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public Ville getPrefecture() {
		return prefecture;
	}

	public void setPrefecture(Ville prefecture) {
		this.prefecture = prefecture;
	}

	@Override
	public String toString() {
		return "Departement [id=" + id + ", numero=" + numero + ", nom=" + nom + ", prefecture=" + prefecture + "]";
	}
	
	
	
	
}
