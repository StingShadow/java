package fr.formation.main;

import java.time.LocalDate;
import java.util.List;

import fr.formation.dal.DaoUtil;
import fr.formation.dal.PersonneDao;
import fr.formation.entity.Personne;

public class AppelJpa {

	public static void main(String[] args) {
		
		
		Personne p1 = new Personne("Lebleu", "Suzon", LocalDate.of(1948, 12, 12));
		Personne p2 = new Personne("Levert", "Suzie", LocalDate.of(2012, 1, 1));
		
		PersonneDao pDao = new PersonneDao();
		System.out.println("p1 avant = " + p1);
		System.out.println("\nTentative d'ajout de p1");
		pDao.add(p1);
		System.out.println("\nTentative d'ajout de p2");
		pDao.add(p2);
		System.out.println("p1 apres = " + p1);

		System.out.println("\nListe des personnes en base  :");
		List<Personne> listeP = pDao.findAll();
		
//		for(int i = 0 ; i < listeP.size(); i++) {
//			System.out.println("  - " + listeP.get(i));
//		}
		
//		for (Personne personne : listeP) {
//			System.out.println("  - " + personne);
//		}
		
		listeP.forEach(p -> System.out.println("  - " + p));
		
		
		DaoUtil.close();
		System.out.println("Fin de mon programme");
	}

}
