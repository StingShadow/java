package fr.formation.dal;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import fr.formation.entity.Personne;

public class PersonneDao {

	private EntityManager em;
	
	public PersonneDao() {
		em = DaoUtil.getEntityManager();
	}
	
	public void add(Personne p) {
		 EntityTransaction et = em.getTransaction();
		 
		 et.begin();
		 try {
			em.persist(p);
			et.commit();
		} catch (Exception e) {
			System.out.println("Probl�me lors de l'ajout de " + p);
			et.rollback();
		}		 
	}
	
	public List<Personne> findAll(){
		String requeteJPQL1 = "Select Object(p) From Personne p"; // Java Persistence Query Language
		String requeteJPQL2 = "Select p From Personne p"; // Java Persistence Query Language
		String requeteJPQL3 = "From Personne p"; // Java Persistence Query Language
		
		return em.createQuery(requeteJPQL2, Personne.class).getResultList();
	}
	
	
	
}
