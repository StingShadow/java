package fr.formation.dal;

import java.util.List;

import javax.persistence.EntityManager;

import fr.formation.entity.Groupe;

public class GroupeDao {

	private EntityManager em;
	
	public GroupeDao() {
		em = DaoUtil.getEntityManager();
	}
	
	
	public void add(Groupe g) {
		em.getTransaction().begin();
		
		try {
			em.persist(g);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
	
	public List<Groupe> findAll(){
		return em
				.createQuery("Select g From Groupe g", Groupe.class)
				.getResultList();
	}
	
	public Groupe findById(int id) {
		return em.find(Groupe.class, id);
	}


	public void update(Groupe g) {
		em.getTransaction().begin();
		
		try {
			em.merge(g);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
	
	
	public void delete(Groupe g) {
		em.getTransaction().begin();
		
		try {
			em.remove(g);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
}
