package fr.formation.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Pays_OTO_Bi")
public class Pays {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String nom;
	
	
	
	@OneToOne(cascade = CascadeType.ALL)
	private Capitale capitale;

	public Pays() {
	}

	
	
	public Pays(String nom) {
		this.nom = nom;
	}
	
	
	public Pays(String nom, Capitale capitale) {
		this.nom = nom;
		this.capitale = capitale;
		this.getCapitale().setPays(this);
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public Capitale getCapitale() {
		return capitale;
	}

	public void setCapitale(Capitale capitale) {
		this.capitale = capitale;
	}

	@Override
	public String toString() {
		return "Pays [id=" + id + ", nom=" + nom + ", capitale=" + capitale.getNom() + "]";
	}
	
	
	
	
}
