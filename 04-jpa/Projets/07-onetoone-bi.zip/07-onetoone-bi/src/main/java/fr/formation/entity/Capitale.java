package fr.formation.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Capitale_OTO_Bi")
public class Capitale {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	
	private String nom;
	
	
	@OneToOne(cascade = CascadeType.ALL, mappedBy = "capitale")
	private Pays pays;

	
	public Capitale() {
	}

	
	
	public Capitale(String nom) {
		this.nom = nom;
	}
	
	
	public Capitale(String nom, Pays pays) {
		this.nom = nom;
		this.pays = pays;
		this.pays.setCapitale(this);
	}



	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public Pays getPays() {
		return pays;
	}


	public void setPays(Pays pays) {
		this.pays = pays;
	}


	@Override
	public String toString() {
		return "Capitale [id=" + id + ", nom=" + nom + ", pays=" + pays.getNom() + "]";
	}
	
	
	
	
}
