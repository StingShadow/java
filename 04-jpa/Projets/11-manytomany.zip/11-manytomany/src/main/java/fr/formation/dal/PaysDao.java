package fr.formation.dal;

import java.util.List;

import javax.persistence.EntityManager;

import fr.formation.entity.Pays;

public class PaysDao {

	private EntityManager em;
	
	public PaysDao() {
		em = DaoUtil.getEntityManager();
	}
	
	
	public void add(Pays p) {
		em.getTransaction().begin();
		
		try {
			em.persist(p);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
	
	public List<Pays> findAll(){
		return em
				.createQuery("Select p From Pays p", Pays.class)
				.getResultList();
	}
	
	public Pays findById(String cle) {
		return em.find(Pays.class, cle);
	}


	public void update(Pays p) {
		em.getTransaction().begin();
		
		try {
			em.merge(p);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
	
	
	public void delete(Pays p) {
		em.getTransaction().begin();
		
		try {
			em.remove(p);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
}
