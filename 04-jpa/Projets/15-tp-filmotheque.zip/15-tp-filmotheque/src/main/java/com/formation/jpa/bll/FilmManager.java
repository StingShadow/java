package com.formation.jpa.bll;

import java.util.List;

import com.formation.jpa.bean.Film;
import com.formation.jpa.dal.DaoFactory;
import com.formation.jpa.dal.FilmDAO;

public class FilmManager {

	FilmDAO dao;
	
	public FilmManager(){
		dao = DaoFactory.getFilmDAO();
	}
	
	public List<Film> listeFilms(){
		return dao.findAll();
	}
	
	public Film trouverFilm(int id){
		return dao.findById(id);
	}
	
	
	public void ajoutFilm(Film f) throws Exception{
		if (f == null || f.getTitre() == null || f.getTitre().isBlank())
			throw new Exception("Film pas correct");
		dao.add(f);
	}
	
	public void modifierFilm(Film f) throws Exception{
//		Film film = dao.findOne(f.getId());
//		film.setActeurs(f.getActeurs());
//		film.setAnnee(f.getAnnee());
//		film.setDuree(f.getDuree());
//		film.setReal(f.getReal());
//		film.setStyle(f.getStyle());
//		film.setSynopsis(f.getSynopsis());
//		film.setTitre(f.getTitre());
//		film.setVu(f.isVu());
//		dao.save(film);
		if (f == null || f.getTitre() == null || f.getTitre().isBlank())
			throw new Exception("Film pas correct");
		dao.update(f);
	}
	
	public void supprimerFilm(Film f) throws Exception{
		dao.delete(f);
	}
	
	public void supprimerFilm(int id) throws Exception{
		dao.delete(trouverFilm(id));
	}

	public List<Film> trier(String par) {
		List<Film> liste = null;
		
		switch (par) {
		default : liste = dao.findAll();

		}
		
		return liste;
	}
	
	
	
}
