package com.formation.jpa.dal;

import java.util.List;

import com.formation.jpa.bean.Film;



public interface FilmDAO{

	
	public void add(Film f) throws Exception;
	public void delete(Film f) throws Exception;
	public  void update(Film f) throws Exception;
	public Film findById(int id);
	public  List<Film> findAll();

}
