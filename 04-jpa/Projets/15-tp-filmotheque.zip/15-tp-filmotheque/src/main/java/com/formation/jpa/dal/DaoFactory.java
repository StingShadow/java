package com.formation.jpa.dal;

public class DaoFactory {

	public static StyleDAO getStyleDAO(){
		return new StyleDAOImpl();
	}
	public static FilmDAO getFilmDAO(){
		return new FilmDAOImpl();
	}
}
