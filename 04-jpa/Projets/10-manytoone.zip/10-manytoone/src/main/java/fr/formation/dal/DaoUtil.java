package fr.formation.dal;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DaoUtil {

	private static EntityManagerFactory emf;
	private static EntityManager em;
	
	public static EntityManager getEntityManager() {
		if (emf == null) {
			emf = Persistence.createEntityManagerFactory("monpu");
			em = emf.createEntityManager();
		}
		
		return em;
	}
	
	public static void close() {
		if (em != null) {
			em.close();
			em = null;
		}
		
		if (emf != null) {
			emf.close();
			emf = null;
		}
	}
}
