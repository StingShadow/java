package fr.formation.main;

import java.util.List;

import fr.formation.dal.CiviliteDao;
import fr.formation.dal.DaoUtil;
import fr.formation.entity.Civilite;

public class GestionCivilites {

	public static void main(String[] args) {
		
		Civilite c1 = new Civilite("Mlle", "Mademoiselle");
		Civilite c2 = new Civilite("Mme", "Madame");
		Civilite c3 = new Civilite("M", "Monsieur");
		
		CiviliteDao cDao = new CiviliteDao();
		cDao.add(c1);
		cDao.add(c2);
		cDao.add(c3);
		
		List<Civilite> listeC = cDao.findAll();
		listeC.forEach(c -> System.out.println("  - " + c));
		
		
		DaoUtil.close();
	}

}
