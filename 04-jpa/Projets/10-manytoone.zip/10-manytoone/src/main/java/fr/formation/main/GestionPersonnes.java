package fr.formation.main;

import java.util.List;

import fr.formation.dal.CiviliteDao;
import fr.formation.dal.DaoUtil;
import fr.formation.dal.PersonneDao;
import fr.formation.entity.Civilite;
import fr.formation.entity.Personne;

public class GestionPersonnes {

	public static void main(String[] args) {
		CiviliteDao cDao = new CiviliteDao();
		PersonneDao pDao = new PersonneDao();
		
		Civilite m = cDao.findById("M");
		Civilite mme = cDao.findById("Mme");
		Civilite mlle = cDao.findById("Mlle");
		
		System.out.println(m);
		System.out.println(mme);
		System.out.println(mlle);
		
		Personne p1 = new Personne("Legrand", "Joe", m);
		Personne p2 = new Personne("Lepetit", "Suzon", mme);
		Personne p3 = new Personne("Lemoyen", "Julie", mme);
		Personne p4 = new Personne("Lebleu", "Juliette", mlle);
		Personne p5 = new Personne("Levert", "Arlette", mme);
		
		pDao.add(p1); pDao.add(p2); pDao.add(p3); pDao.add(p4); pDao.add(p5); 
		
		
		
		List<Personne> listeP = pDao.findAll();
		listeP.forEach(p -> System.out.println(p.getCivilite().getLibelle() + " " + p.getPrenom() + " " + p.getNom()));
		
		// Suppression
		listeP.forEach(p -> pDao.delete(p));
		
		DaoUtil.close();
	}

}
