package fr.formation.dal;

import java.util.List;

import javax.persistence.EntityManager;

import fr.formation.entity.Civilite;
import fr.formation.entity.Personne;

public class CiviliteDao {

	private EntityManager em;
	
	public CiviliteDao() {
		em = DaoUtil.getEntityManager();
	}
	
	
	public void add(Civilite c) {
		em.getTransaction().begin();
		
		try {
			em.persist(c);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
	
	public List<Civilite> findAll(){
		return em
				.createQuery("Select c From Civilite c", Civilite.class)
				.getResultList();
	}
	
	public Civilite findById(String cle) {
		return em.find(Civilite.class, cle);
	}


	public void update(Civilite c) {
		em.getTransaction().begin();
		
		try {
			em.merge(c);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
	
	
	public void delete(Civilite c) {
		em.getTransaction().begin();
		
		try {
			em.remove(c);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
}
