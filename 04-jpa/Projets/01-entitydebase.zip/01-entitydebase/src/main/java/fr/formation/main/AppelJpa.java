package fr.formation.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import fr.formation.entity.User;

public class AppelJpa {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("monpu");
		EntityManager em = emf.createEntityManager();
		
		User u1 = new User(1, "Joe", "azerty");
		User u2 = new User(2, "Jack", "123");
		User u3 = new User(3, "Jack", "123");
		
		
		// Choix TOUT OU RIEN
		em.getTransaction().begin();
		
		try {
			em.persist(u1);
			em.persist(u2);
			em.persist(u3);
			em.getTransaction().commit();
		} catch (Exception e) {
			em.getTransaction().rollback();
			System.out.println("Un probl�me est survenu lors de l'ajout : " + e.getMessage());
		}
		
		
		
		
		em.close();
		emf.close();
		
		System.out.println("Fin de mon programme");
	}

}
