package fr.formation.controller.api;

public class PersonneWSProxy implements fr.formation.controller.api.PersonneWS {
  private String _endpoint = null;
  private fr.formation.controller.api.PersonneWS personneWS = null;
  
  public PersonneWSProxy() {
    _initPersonneWSProxy();
  }
  
  public PersonneWSProxy(String endpoint) {
    _endpoint = endpoint;
    _initPersonneWSProxy();
  }
  
  private void _initPersonneWSProxy() {
    try {
      personneWS = (new fr.formation.controller.api.PersonneWSServiceLocator()).getPersonneWSPort();
      if (personneWS != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)personneWS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)personneWS)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (personneWS != null)
      ((javax.xml.rpc.Stub)personneWS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public fr.formation.controller.api.PersonneWS getPersonneWS() {
    if (personneWS == null)
      _initPersonneWSProxy();
    return personneWS;
  }
  
  public fr.formation.controller.api.Personne[] liste() throws java.rmi.RemoteException{
    if (personneWS == null)
      _initPersonneWSProxy();
    return personneWS.liste();
  }
  
  public boolean ajout(fr.formation.controller.api.Personne arg0) throws java.rmi.RemoteException{
    if (personneWS == null)
      _initPersonneWSProxy();
    return personneWS.ajout(arg0);
  }
  
  
}