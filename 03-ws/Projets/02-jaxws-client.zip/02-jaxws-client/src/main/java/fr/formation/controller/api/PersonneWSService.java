/**
 * PersonneWSService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package fr.formation.controller.api;

public interface PersonneWSService extends javax.xml.rpc.Service {
    public java.lang.String getPersonneWSPortAddress();

    public fr.formation.controller.api.PersonneWS getPersonneWSPort() throws javax.xml.rpc.ServiceException;

    public fr.formation.controller.api.PersonneWS getPersonneWSPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
