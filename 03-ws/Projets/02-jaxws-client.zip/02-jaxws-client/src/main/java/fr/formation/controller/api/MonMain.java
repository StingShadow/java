package fr.formation.controller.api;

import javax.xml.rpc.ServiceException;

public class MonMain {

	public static void main(String[] args) {
		PersonneWSServiceLocator locator = new PersonneWSServiceLocator();
		try {
			PersonneWS ws = locator.getPersonneWSPort();
			Personne[] liste = ws.liste();
			for (int i = 0 ; i < liste.length; i++) {
				System.out.println(liste[i]);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
