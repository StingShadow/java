/**
 * PersonneWS.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package fr.formation.controller.api;

public interface PersonneWS extends java.rmi.Remote {
    public fr.formation.controller.api.Personne[] liste() throws java.rmi.RemoteException;
    public boolean ajout(fr.formation.controller.api.Personne arg0) throws java.rmi.RemoteException;
}
