
$(function(){
	$("#bAlea").on("click", appelAlea);
});


function appelAlea(){
	$.get("http://localhost:8080/04-jaxrs-serveur/rs/calcul/alea", ttmtAlea)
	.fail(errorAlea);
	
}


function ttmtAlea(val){
	$("#divAlea").html(val);
}
function errorAlea(err){
	console.log(err);
	$("#divAlea").html("Nombre trop grand ("+err.status+")");
}