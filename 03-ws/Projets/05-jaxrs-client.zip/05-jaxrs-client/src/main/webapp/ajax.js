
$(function(){
	$("#bAlea").on("click", appelAlea);
	$("#bClimat").on("click", appelClimat);
	$("#bAjout").on("click", appelAjout);
	$("#bSuppr").on("click", appelSuppr);
});


function appelAjout(){
	var zone = $("#zone").val();
	var temperature = $("#temperature").val();
	var nuageux = $("#nuageux").prop("checked");
	console.log(zone + " " + temperature + " " + nuageux);
	
	var data = {
		zone : zone,
		temperature : temperature,
		nuageux : nuageux
	}
	
	console.log(data);
	
	$.ajax({
		type : 'post',
		url : 'http://localhost:8080/04-jaxrs-serveur/rs/climats',
		data : JSON.stringify(data),
		contentType : "application/json;charset=utf-8",
		success : function(){
			appelClimat();
		}
	})
	
}


function appelSuppr(){
	$.ajax({
		url : "http://localhost:8080/04-jaxrs-serveur/rs/climats/" + $("#numero").val(),
		type : "DELETE",
		success : okSuppr,	
	})
	.fail(errorSuppr);
	
}

function okSuppr(){
	$("#divSuppr").html("<span class='success'>La suppression s'est effectuée correctement</span>");
	appelClimat();
}

function errorSuppr(){
	$("#divSuppr").html("<span class='error'>La suppression ne s'est pas effectuée correctement</span>");
}

function appelAlea(){
	$.get("http://localhost:8080/04-jaxrs-serveur/rs/calcul/alea", ttmtAlea)
	.fail(errorAlea);
	
}

function appelClimat(){
	$.get("http://localhost:8080/04-jaxrs-serveur/rs/climats", affClimats, 'json');
	
}


function ttmtAlea(val){
	$("#divAlea").html(val);
}
function errorAlea(err){
	console.log(err);
	$("#divAlea").html("Nombre trop grand ("+err.status+")");
}

function affClimats(data){
	console.log(data);
	var chaine = "<ul>";
	
	data.forEach(function(c){
		chaine += "<li>" + c.zone + " : " + c.temperature + "°C" + 
		(c.nuageux ? " nuageux" : " dégagé")
		+"</li>";
	});
	
	chaine +="</ul>";
	$("#divClimat").html(chaine);
}