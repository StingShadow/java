package fr.formation.bibliotheque.exception;

public class LivreException extends Exception{

	public LivreException(String message) {
		super(message);
	}
}
