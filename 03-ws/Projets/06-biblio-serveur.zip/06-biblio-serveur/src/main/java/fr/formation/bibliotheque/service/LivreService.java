package fr.formation.bibliotheque.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import fr.formation.bibliotheque.dal.DaoFactory;
import fr.formation.bibliotheque.dal.LivreDao;
import fr.formation.bibliotheque.exception.LivreException;
import fr.formation.bibliotheque.model.Livre;

public class LivreService {

	private LivreDao dao;
	
	public LivreService() {
		dao = DaoFactory.getLivreDao();
	}
	
	public void ajouterLivre(Livre l) throws LivreException {
		validerLivre(l);
		dao.add(l);
	}

	private void validerLivre(Livre l)  throws LivreException{
		if (l == null)
			throw new LivreException("Le livre ne doit pas etre nul");
		if (l.getTitre() == null || l.getTitre().isBlank())
			throw new LivreException("Le titre est obligatoire");
		if (l.getAuteur() == null || l.getAuteur().isBlank())
			throw new LivreException("L'auteur est obligatoire");
		if (l.getNbPages() <= 0)
			throw new LivreException("Le nombre de page doit etre strictement positif");
		if (l.getIsbn() == null || l.getIsbn().isBlank())
			throw new LivreException("L'ISBN est obligatoire");
		if (l.getDateAchat() == null )
			throw new LivreException("La date d'achat est obligatoire");
		if (l.getDateAchat().isAfter(LocalDate.now()) )
			throw new LivreException("La date d'achat doit est anterieure a aujourd'hui");

	}

	public List<Livre> listerLivres() throws LivreException {
		
		return dao.findAll();
	}

	public void supprimerLivre(int id) throws LivreException {
		
		dao.delete(id);
	}

	public List<Livre> trouverLivresParAuteur(String auteur) throws LivreException {
		return dao.findByAuteur(auteur);
	}
	
	public List<Livre> trouverLivresParTitre(String titre) throws LivreException {
		return dao.findByTitre(titre);
	}

	public Optional<Livre> trouverLivresParId(int id) throws LivreException {
		return dao.findById(id);
	}

	public void modifierLivre(Livre l)  throws LivreException{
		validerLivre(l);
		dao.update(l);
	}
}
