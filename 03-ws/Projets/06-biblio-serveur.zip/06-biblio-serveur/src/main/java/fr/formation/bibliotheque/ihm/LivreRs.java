package fr.formation.bibliotheque.ihm;

import java.util.List;
import java.util.Optional;

import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import fr.formation.bibliotheque.exception.LivreException;
import fr.formation.bibliotheque.model.Livre;
import fr.formation.bibliotheque.service.LivreService;

@Path("/biblio")
@Singleton
public class LivreRs {
	

	private LivreService ls;
	
	public LivreRs() {
		ls = new LivreService();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Livre> listeLivres(){
		try {
			List<Livre> liste = ls.listerLivres();
			return liste;
		} catch (LivreException e) {
			throw new WebApplicationException(Response.Status.CONFLICT);
		}
	}	
	
	@Path("/nb")
	@GET
	public int nbLivres(){
		try {
			List<Livre> liste = ls.listerLivres();
			return liste.size();
		} catch (LivreException e) {
			throw new WebApplicationException(Response.Status.CONFLICT);
		}
	}
	
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void postLivre(Livre l) {
		try {
			System.out.println("Ajout de " + l);
			ls.ajouterLivre(l);
		} catch (LivreException e) {
			throw new WebApplicationException(Response.Status.CONFLICT);
		}
	}
	
	
	
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	public void putLivre(Livre l, @PathParam("id") int id) {
		try {
			l.setId(id);
			ls.modifierLivre(l);
		} catch (LivreException e) {
			throw new WebApplicationException(Response.Status.CONFLICT);
		}
	}
	
	

	@DELETE
	@Path("/{id}")
	public void removeLivre(@PathParam("id") int id) {
		try {
			ls.supprimerLivre(id);
		} catch (LivreException e) {
			throw new WebApplicationException(Response.Status.CONFLICT);
		}
	}
	
	
	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Livre getLivre(@PathParam("id") int id) {
		try {
			Optional<Livre> optL = ls.trouverLivresParId(id);
			if (optL.isPresent())
				return optL.get();
			else
				throw new WebApplicationException(Response.Status.CONFLICT);
		} catch (LivreException e) {
			throw new WebApplicationException(Response.Status.CONFLICT);
		}
	}
	
}
