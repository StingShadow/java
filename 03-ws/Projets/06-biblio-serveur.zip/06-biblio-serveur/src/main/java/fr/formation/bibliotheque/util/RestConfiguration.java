package fr.formation.bibliotheque.util;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/rs")
public class RestConfiguration extends Application{

}
