package fr.formation.bibliotheque.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Saisie {
	
	static private Scanner sc = new Scanner(System.in);;
	
	
	
	public static  int scanEntier(String message) {
		int val = 0;
		boolean isOK = false;
		do {
			System.out.println(message);
			try {
				val = sc.nextInt();
				sc.nextLine();
				isOK = true;
			} catch (Exception e) {
				sc.nextLine();
			}
		}
		while(!isOK);
		return val;
	}	
	
	public static String scanChaine(String message) {
		System.out.println(message);
		return sc.nextLine();
	}
	
	public static LocalDate scanLocalDate(String message) {
		LocalDate localDate = null;
		boolean isOK = false;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		do {
			System.out.println(message);
			try {
				String chaine = sc.nextLine();
				localDate = LocalDate.parse(chaine, formatter);
				isOK = true;
			} catch (Exception e) {
				
			}
		}
		while(!isOK);
		return localDate;
	}	
}
