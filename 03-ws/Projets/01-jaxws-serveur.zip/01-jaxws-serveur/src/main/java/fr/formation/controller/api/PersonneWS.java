package fr.formation.controller.api;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebService;

import fr.formation.model.Personne;

@WebService
public class PersonneWS {

	private List<Personne> personnes;
	
	public PersonneWS() {
		personnes = new ArrayList<Personne>();
		personnes.add(new Personne("Lebleu", "Suzon", 66));
		personnes.add(new Personne("Levert", "Joe", 55));
	}
	
	public List<Personne> liste(){
		System.out.println("Appel de la m�thode liste()");
		return personnes;
	}
	
	public boolean ajout(Personne p){
		System.out.println("Appel de la m�thode ajout()");
		if (p == null)
			return false;
		
		return personnes.add(p);
	}
	
	
}
