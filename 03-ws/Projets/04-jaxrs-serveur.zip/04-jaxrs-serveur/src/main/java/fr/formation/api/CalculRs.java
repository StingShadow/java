package fr.formation.api;

import java.util.Random;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

@Path("/calcul")
public class CalculRs {

	
	@GET
	@Path("/alea")
	public int alea() {
		int a = new Random().nextInt(100);
		if (a < 50)
			return a;
		
		else throw new WebApplicationException(Response.Status.SERVICE_UNAVAILABLE);
	}
}
