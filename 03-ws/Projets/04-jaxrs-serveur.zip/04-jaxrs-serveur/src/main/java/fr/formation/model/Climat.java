package fr.formation.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Climat {

	private float temperature;
	private boolean nuageux;
	private String zone;
	
	public Climat() {
	}
	public Climat(float temperature, boolean nuageux, String zone) {
		this.temperature = temperature;
		this.nuageux = nuageux;
		this.zone = zone;
	}
	public float getTemperature() {
		return temperature;
	}
	public void setTemperature(float temperature) {
		this.temperature = temperature;
	}
	public boolean isNuageux() {
		return nuageux;
	}
	public void setNuageux(boolean nuageux) {
		this.nuageux = nuageux;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	@Override
	public String toString() {
		return "Climat [temperature=" + temperature + ", nuageux=" + nuageux + ", zone=" + zone + "]";
	}

	
	
	
}
