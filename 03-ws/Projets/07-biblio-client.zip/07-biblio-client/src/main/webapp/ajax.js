$(function(){
	clickAccueil();

	$("#accueil").on ("click", clickAccueil);
	$("#liste").on ("click", clickListe);
	$("#ajout").on ("click", clickAjout);
//	$("#edit").on ("click", clickEdit);
	
	$("#ajoutlivre").on ("click", ajoutLivre);
	$("#editlivre").on ("click", editLivre);
});

function ajoutLivre(){
	
	var data = {
		titre : $("#titreL").val(),
		auteur : $("#auteurL").val(),
		nbPages : $("#nbpagesL").val(),
		dateAchat :$("#dateL").val(),
		isbn :$("#isbnL").val()
	}
	

	$.ajax({
		type : 'post',
		url : 'http://localhost:8080/06-biblio-serveur/rs/biblio',
		data : JSON.stringify(data),
		contentType : "application/json;charset=utf-8",
		success : function(){
			clickListe();
		}
	})
	.fail(function(){
		$("#ajouterror").html("Une erreur est survenue lors de l'ajout'");
	})
	
}


function editLivre(){
	
	var data = {
		titre : $("#titreL").val(),
		auteur : $("#auteurL").val(),
		nbPages : $("#nbpagesL").val(),
		dateAchat :$("#dateL").val(),
		isbn :$("#isbnL").val()
	}
	

	$.ajax({
		type : 'put',
		url : 'http://localhost:8080/06-biblio-serveur/rs/biblio/'+$("#idL").val(),
		data : JSON.stringify(data),
		contentType : "application/json;charset=utf-8",
		success : function(){
			clickListe();
		}
	})
	.fail(function(){
		$("#ajouterror").html("Une erreur est survenue lors de la modification'");
	})
	
}
function clickAccueil(){
	$(".div").css("display", "none");
	$(".nav-link").removeClass("active");
	$("#accueil").addClass("active");
	$("#divaccueil").css("display", "block");

	$.get("http://localhost:8080/06-biblio-serveur/rs/biblio/nb")
	.then(function(res){
		console.log(res);
		$("#nblivres").html("" + res + " livre" + (res > 1 ? "s" : ""));
	});
}

function clickListe(){
	$(".div").css("display", "none");
	$(".nav-link").removeClass("active");
	$("#liste").addClass("active");
	$("#divliste").css("display", "block");
	$("#supperror").html("");

	$.get("http://localhost:8080/06-biblio-serveur/rs/biblio")
	.then(function(liste){
		var data = "";
		liste.forEach(function(c){
			var tr = "<tr>";
			tr += "<td>"+c.auteur +"</td>";
			tr += "<td>"+c.titre +"</td>";
			tr += "<td>"+c.nbPages +"</td>";
			tr += "<td>"+c.dateAchat +"</td>";
			tr += "<td>"+c.isbn +"</td>";
			tr += "<td><a onclick='suppLivre("+c.id +")' href='#'>Supprimer</a></td>";
			tr += "<td><a onclick='modifLivre("+c.id +")' href='#'>Modifier</a></td>";
			tr += "</tr>"
			data += tr;
		});
			
		console.log(data)
		$("#divliste tbody").html(data);
	});

}


function suppLivre(id){
	$.ajax({
		type : 'delete',
		url : 'http://localhost:8080/06-biblio-serveur/rs/biblio/' + id,
		success : function(){
			clickListe();
		}
	})
	.fail(function(){
		$("#supperror").html("Une erreur est survenue lors de la suppression'");
	})
}


function modifLivre(id){
	$.ajax({
		type : 'get',
		url : 'http://localhost:8080/06-biblio-serveur/rs/biblio/' + id,
		success : function(l){
			clickEdit(l);
		}
	})
	.fail(function(){
		$("#supperror").html("Une erreur est survenue lors de la modification'");
	})
}



function clickAjout(){
	$(".div").css("display", "none");
	$(".nav-link").removeClass("active");
	$("#ajout").addClass("active");
	$("#divajout").css("display", "block");
	$("#ajouterror").html("");

	$("#editlivre").css("display", "none");
	$("#ajoutlivre").css("display", "inline-block");
}

function clickEdit(l){
	$(".div").css("display", "none");
	$(".nav-link").removeClass("active");
	$("#edit").addClass("active");
	$("#divajout").css("display", "block");
	$("#divajout h2").html("Modification du livre");

	$("#editlivre").css("display", "inline-block");
	$("#ajoutlivre").css("display", "none");

	console.log(l)
	$("#titreL").val(l.titre);
	$("#auteurL").val(l.auteur);
	$("#nbpagesL").val(l.nbPages);
	$("#dateL").val(l.dateAchat);
	$("#isbnL").val(l.isbn);
	$("#idL").val(l.id);
	
}