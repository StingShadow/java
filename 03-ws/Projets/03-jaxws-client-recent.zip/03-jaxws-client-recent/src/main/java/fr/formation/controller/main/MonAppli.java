package fr.formation.controller.main;

import java.util.List;

import fr.formation.controller.api.Personne;
import fr.formation.controller.api.PersonneWS;
import fr.formation.controller.api.PersonneWSService;

public class MonAppli {

	public static void main(String[] args) {
		PersonneWSService serv = new PersonneWSService();
		PersonneWS ws = serv.getPersonneWSPort();
		
		Personne p = new Personne(69, "Lerouge"	, "Dam");
		ws.ajout(p);		
		
		List<Personne> listeP = ws.liste();

		for (Personne personne : listeP) {
			System.out.println(personne);
		}

	}

}
