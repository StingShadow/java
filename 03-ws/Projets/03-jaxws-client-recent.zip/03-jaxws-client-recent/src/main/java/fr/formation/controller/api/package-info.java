@javax.xml.bind.annotation.XmlSchema(namespace = "http://api.controller.formation.fr/")
package fr.formation.controller.api;
