
package fr.formation.controller.api;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the fr.formation.controller.api package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Ajout_QNAME = new QName("http://api.controller.formation.fr/", "ajout");
    private final static QName _Liste_QNAME = new QName("http://api.controller.formation.fr/", "liste");
    private final static QName _AjoutResponse_QNAME = new QName("http://api.controller.formation.fr/", "ajoutResponse");
    private final static QName _ListeResponse_QNAME = new QName("http://api.controller.formation.fr/", "listeResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: fr.formation.controller.api
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ListeResponse }
     * 
     */
    public ListeResponse createListeResponse() {
        return new ListeResponse();
    }

    /**
     * Create an instance of {@link Liste }
     * 
     */
    public Liste createListe() {
        return new Liste();
    }

    /**
     * Create an instance of {@link AjoutResponse }
     * 
     */
    public AjoutResponse createAjoutResponse() {
        return new AjoutResponse();
    }

    /**
     * Create an instance of {@link Ajout }
     * 
     */
    public Ajout createAjout() {
        return new Ajout();
    }

    /**
     * Create an instance of {@link Personne }
     * 
     */
    public Personne createPersonne() {
        return new Personne();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ajout }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api.controller.formation.fr/", name = "ajout")
    public JAXBElement<Ajout> createAjout(Ajout value) {
        return new JAXBElement<Ajout>(_Ajout_QNAME, Ajout.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Liste }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api.controller.formation.fr/", name = "liste")
    public JAXBElement<Liste> createListe(Liste value) {
        return new JAXBElement<Liste>(_Liste_QNAME, Liste.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AjoutResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api.controller.formation.fr/", name = "ajoutResponse")
    public JAXBElement<AjoutResponse> createAjoutResponse(AjoutResponse value) {
        return new JAXBElement<AjoutResponse>(_AjoutResponse_QNAME, AjoutResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api.controller.formation.fr/", name = "listeResponse")
    public JAXBElement<ListeResponse> createListeResponse(ListeResponse value) {
        return new JAXBElement<ListeResponse>(_ListeResponse_QNAME, ListeResponse.class, null, value);
    }

}
