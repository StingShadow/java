package fr.formation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestConnexion {

	public static void main(String[] args) {

		try {
			Class.forName("org.h2.Driver");
			Connection conn = DriverManager.getConnection("jdbc:h2:~/formation", "form", "ation");
			System.out.println("Connexion effectu�e");
			
			String requete = "Select id, nom, prenom, age FROM personne";
			Statement stt = conn.createStatement();
			ResultSet rs = stt.executeQuery(requete);
			
			System.out.println("Liste des personnes en base : ");
			while(rs.next()) {
				long id = rs.getLong("id");
				String nom = rs.getString(2);
				String prenom = rs.getString("prenom");
				int age = rs.getInt(4);
				System.out.println("   - " + id + " : " + prenom + " " + nom + " (" + age + " ans)");
			}
			
			conn.close();
		} catch (ClassNotFoundException e) {
			System.out.println("Driver non trouv�");
		} catch (SQLException e) {
			System.out.println("Connexion non effectu�e : " + e.getMessage());
		}
		
		
		
		
		
		
		System.out.println("Fin du programme");
	}

}
