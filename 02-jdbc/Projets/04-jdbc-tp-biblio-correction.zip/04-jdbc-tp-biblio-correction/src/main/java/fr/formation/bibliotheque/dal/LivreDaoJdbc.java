package fr.formation.bibliotheque.dal;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import fr.formation.bibliotheque.exception.LivreException;
import fr.formation.bibliotheque.model.Livre;

public class LivreDaoJdbc implements LivreDao {

	private static final String SELECTALL = "Select id, titre, auteur, nbpages, isbn, dateachat FROM livre";
	private static final String SELECTALLBYAUTEUR = "Select id, titre, auteur, nbpages, isbn, dateachat FROM livre where auteur LIKE ?";
	private static final String SELECTALLBYTITRE = "Select id, titre, auteur, nbpages, isbn, dateachat FROM livre where titre LIKE ?";
	private static final String SELECTONE = "Select id, titre, auteur, nbpages, isbn, dateachat FROM livre where id = ?";
	private static final String INSERT = "INSERT INTO livre (titre, auteur, nbpages, isbn, dateachat) values(?, ?, ?, ?, ?)";
	private static final String UPDATE = "UPDATE livre SET titre = ?, auteur = ?, nbpages = ?, isbn = ?, dateachat = ? WHERE id = ?";
	private static final String DELETE = "DELETE FROM livre where id = ?";

	public LivreDaoJdbc() {
		initBase();
	}
	
	private void initBase() {
		final String CREATETABLE = "create table livre(id int primary key AUTO_INCREMENT, titre varchar(50), auteur varchar(45), nbpages int, isbn varchar(20) unique, dateachat DATE);"; 
		try {
			Statement stt = DaoUtil.getConnection().createStatement();
			stt.executeUpdate(CREATETABLE);
			add(new Livre("Les fleurs du mal", "Baudelaire", 235, LocalDate.of(2020, 10, 10), "123456789"));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void add(Livre l) throws LivreException {
		try {
			PreparedStatement pstt = DaoUtil.getConnection().prepareStatement(INSERT, Statement.RETURN_GENERATED_KEYS);
			pstt.setString(1, l.getTitre());
			pstt.setString(2, l.getAuteur());
			pstt.setInt(3, l.getNbPages());
			pstt.setString(4, l.getIsbn());
			pstt.setDate(5, Date.valueOf(l.getDateAchat()));
			pstt.executeUpdate();
			
			ResultSet rs = pstt.getGeneratedKeys();
			
			if (rs.next()) {
				int cle = rs.getInt(1);
				l.setId(cle);
			}
		} catch (SQLException e) {
			if (e.getMessage().contains("unique"))
				throw new LivreException("L'isbn doit etre unique");
			else
				throw new LivreException("Probleme lors de l'appel a add : " + e.getMessage());
		}
		
	}

	@Override
	public void update(Livre l) throws LivreException {
		try {
			PreparedStatement pstt = DaoUtil.getConnection().prepareStatement(UPDATE);
			pstt.setString(1, l.getTitre());
			pstt.setString(2, l.getAuteur());
			pstt.setInt(3, l.getNbPages());
			pstt.setString(4, l.getIsbn());
			pstt.setDate(5, Date.valueOf(l.getDateAchat()));
			pstt.setInt(6, l.getId());
			pstt.executeUpdate();
			
			pstt.getGeneratedKeys();
			
		} catch (SQLException e) {
			if (e.getMessage().contains("unique"))
				throw new LivreException("L'isbn doit etre unique");
			else
				throw new LivreException("Probleme lors de l'appel a add : " + e.getMessage());
		}
		
	}
	
	@Override
	public Optional<Livre> findById(int id) throws LivreException {
		Optional<Livre> optL = Optional.empty();
		try {
			PreparedStatement pstt = DaoUtil.getConnection().prepareStatement(SELECTONE);
			pstt.setInt(1, id);
			ResultSet rs = pstt.executeQuery();
			if (rs.next()) {
				String titre = rs.getString("titre");
				String auteur = rs.getString("auteur");
				int nbPages = rs.getInt("nbpages");
				String isbn = rs.getString("isbn");
				LocalDate dateAchat = rs.getDate("dateachat").toLocalDate();
				Livre l = new Livre(id, titre, auteur, nbPages, dateAchat, isbn);
				optL = Optional.of(l);
			}
		} catch (SQLException e) {
			throw new LivreException("Probleme lors de l'appel a findById : " + e.getMessage());
		}
		
		
		return optL;
	}

	@Override
	public List<Livre> findAll()throws LivreException  {
		List<Livre> maListe = new ArrayList<Livre>();
		try {
			Statement stt = DaoUtil.getConnection().createStatement();
			ResultSet rs = stt.executeQuery(SELECTALL);
			while(rs.next()) {
				int id = rs.getInt("id");
				String titre = rs.getString("titre");
				String auteur = rs.getString("auteur");
				int nbPages = rs.getInt("nbpages");
				String isbn = rs.getString("isbn");
				LocalDate dateAchat = rs.getDate("dateachat").toLocalDate();
				Livre l = new Livre(id, titre, auteur, nbPages, dateAchat, isbn);
				maListe.add(l);
			}
		} catch (SQLException e) {
			throw new LivreException("Probleme lors de l'appel a findAll : " + e.getMessage());
		}
		
		return maListe;
	}

	@Override
	public List<Livre> findByAuteur(String a) throws LivreException {
		List<Livre> maListe = new ArrayList<Livre>();
		try {
			PreparedStatement pstt = DaoUtil.getConnection().prepareStatement(SELECTALLBYAUTEUR);
			pstt.setString(1, "%"+a+"%");
			ResultSet rs = pstt.executeQuery();
			while(rs.next()) {
				int id = rs.getInt("id");
				String titre = rs.getString("titre");
				String auteur = rs.getString("auteur");
				int nbPages = rs.getInt("nbpages");
				String isbn = rs.getString("isbn");
				LocalDate dateAchat = rs.getDate("dateachat").toLocalDate();
				Livre l = new Livre(id, titre, auteur, nbPages, dateAchat, isbn);
				maListe.add(l);
			}
		} catch (SQLException e) {
			throw new LivreException("Probleme lors de l'appel a findByAuteur : " + e.getMessage());
		}
		
		return maListe;
	}
	@Override
	public List<Livre> findByTitre(String t) throws LivreException {
		List<Livre> maListe = new ArrayList<Livre>();
		try {
			PreparedStatement pstt = DaoUtil.getConnection().prepareStatement(SELECTALLBYTITRE);
			pstt.setString(1, "%"+t+"%");
			ResultSet rs = pstt.executeQuery();
			while(rs.next()) {
				int id = rs.getInt("id");
				String titre = rs.getString("titre");
				String auteur = rs.getString("auteur");
				int nbPages = rs.getInt("nbpages");
				String isbn = rs.getString("isbn");
				LocalDate dateAchat = rs.getDate("dateachat").toLocalDate();
				Livre l = new Livre(id, titre, auteur, nbPages, dateAchat, isbn);
				maListe.add(l);
			}
		} catch (SQLException e) {
			throw new LivreException("Probleme lors de l'appel a findByTitre : " + e.getMessage());
		}
		
		return maListe;
	}

	@Override
	public void delete(int id) throws LivreException {
		try {
			PreparedStatement pstt = DaoUtil.getConnection().prepareStatement(DELETE);
			pstt.setInt(1, id);
			int nbLignes = pstt.executeUpdate();
			if (nbLignes == 0)
				throw new LivreException("Aucun livre ne correspond a l'id : " + id);
		} catch (SQLException e) {
			throw new LivreException("Probleme lors de l'appel a delete : " + e.getMessage());
		}
		
	}

}
