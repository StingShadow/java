package fr.formation.bibliotheque.dal;

import java.util.List;
import java.util.Optional;

import fr.formation.bibliotheque.exception.LivreException;
import fr.formation.bibliotheque.model.Livre;

public interface LivreDao {

	void add(Livre l) throws LivreException;

	List<Livre> findAll() throws LivreException;

	List<Livre> findByAuteur(String auteur) throws LivreException;
	List<Livre> findByTitre(String titre) throws LivreException;

	void delete(int id) throws LivreException;

	Optional<Livre> findById(int id) throws LivreException;

	void update(Livre l) throws LivreException;

}
