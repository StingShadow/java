package fr.formation.bibliotheque.ihm;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import fr.formation.bibliotheque.exception.LivreException;
import fr.formation.bibliotheque.model.Livre;
import fr.formation.bibliotheque.service.LivreService;
import fr.formation.bibliotheque.util.Saisie;

public class MonAppli {
	
	private static LivreService ls;
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ls = new LivreService();
		int choix = 0;
		do {
			menu();
			choix = Saisie.scanEntier("Votre choix :");
			
			switch (choix) {
			case 1:
				ajouterLivre();
				break;
			case 2:
				afficherLivres();
				break;
			case 3:
				trouverLivreParAuteur();
				break;
			case 4:
				trouverLivreParTitre();
				break;
			case 5:
				modifierLivre();
				break;
			case 6:
				supprimerLivre();
				break;
			}
		}
		while (choix != 0);
		
		sc.close();
	}

	private static void supprimerLivre() {
		System.out.println("\n    SUPPRESSION D'UN LIVRE");
		System.out.println("    ----------------------");
		
		int id = Saisie.scanEntier("Id du livre a supprimer :");
		
		try {
			ls.supprimerLivre(id);
			System.out.println("Le livre a bien ete supprime de la base");
		} catch (LivreException e) {
			System.out.println(e.getMessage());
		}
	}

	private static void modifierLivre() {
		System.out.println("\n    MODIFICATION D'UN LIVRE");
		System.out.println("    -----------------------");
		
		int id = Saisie.scanEntier("Id du livre a modifier :");
		
		try {
			Optional<Livre> optL = ls.trouverLivresParId(id);
			if (optL.isEmpty())
				System.out.println("Aucun livre ne correspond");
			else {
				System.out.println("Livre a modifier : " + optL.get());
				Livre l = saisieLivre();
				l.setId(id);
				ls.modifierLivre(l);
			}
		} catch (LivreException e) {
			System.out.println(e.getMessage());
		}
	}

	private static void trouverLivreParTitre() {
		
		System.out.println("\n    RECHERCHE D'UN LIVRE PAR TITRE");
		System.out.println("    -------------------------------");
		String titre = Saisie.scanChaine("Titre : ");
		
		try {
			List<Livre> listeL = ls.trouverLivresParTitre(titre);
			for (Livre livre : listeL) {
				System.out.println("   - " + livre);
			}
		} catch (LivreException e) {
			e.printStackTrace();
		}
		
	}

	private static void trouverLivreParAuteur() {
		
		System.out.println("\n    RECHERCHE D'UN LIVRE PAR AUTEUR");
		System.out.println("    -------------------------------");
		String auteur = Saisie.scanChaine("Auteur : ");
		
		try {
			List<Livre> listeL = ls.trouverLivresParAuteur(auteur);
			for (Livre livre : listeL) {
				System.out.println("   - " + livre);
			}
		} catch (LivreException e) {
			e.printStackTrace();
		}
	}

	private static void afficherLivres() {
		System.out.println("\n    LISTE DES LIVRES");
		System.out.println("    ----------------");
		try {
			List<Livre> listeL = ls.listerLivres();
			for (Livre livre : listeL) {
				System.out.println("   - " + livre);
			}
		} catch (LivreException e) {
			e.printStackTrace();
		}
		
	}

	private static void ajouterLivre() {
		System.out.println("\n    AJOUT D'UN LIVRE");
		System.out.println("    ----------------");
		
		Livre l = saisieLivre();
		try {
			ls.ajouterLivre(l);
		} catch (LivreException e) {
			System.out.println(e.getMessage());
			
		}
	}

	private static Livre saisieLivre() {
		String titre = Saisie.scanChaine("Titre du livre : ");
		String auteur = Saisie.scanChaine("Auteur du livre : ");
		int nbPages = Saisie.scanEntier("Nombre de pages du livre : ");
		LocalDate dateAchat = Saisie.scanLocalDate("Date d'achat (format jj/mm/aaaa) : ");
		String isbn = Saisie.scanChaine("ISBN du livre : ");
		
		Livre l = new Livre(titre, auteur, nbPages, dateAchat, isbn);
		return l;
	}

	private static void menu() {
		
		
		System.out.println("\n    MENU PRINCIPAL");
		System.out.println("    --------------");
		System.out.println();
		System.out.println();
		System.out.println("   0 : Quitter");
		System.out.println("   1 : Ajouter un livre");
		System.out.println("   2 : Afficher la liste des livres");
		System.out.println("   3 : Trouver un livre par son auteur");
		System.out.println("   4 : Trouver un livre par son titre");
		System.out.println("   5 : Modifier un livre");
		System.out.println("   6 : Supprimer un livre");
				
	}
	

}
