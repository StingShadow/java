package fr.formation.bibliotheque.dal;

import java.sql.Connection;
import java.sql.DriverManager;

public class DaoUtil {
	
	private static final String URL = "jdbc:h2:mem:test";
	private static final String LOGIN = "root";
	private static final String PASSWD = "1234";
	
	private static Connection conn;
	
	public static Connection getConnection() {
		
		if (conn == null) {
			try {
				conn = DriverManager.getConnection(URL, LOGIN, PASSWD);
			} catch (Exception e) {
				System.out.println("Connexion non effectu�e : " +e.getMessage());
				conn = null;
			} 
		}
		return conn;
	}
	
	
	public static void close() {
		try {
			conn.close();
		} catch (Exception e) {
			System.out.println("Probleme de fermeture de connexion : " +e.getMessage());
		}
		conn = null;
	}
}
