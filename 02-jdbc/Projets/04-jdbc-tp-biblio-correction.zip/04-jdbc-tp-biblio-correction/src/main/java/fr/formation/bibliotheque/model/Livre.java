package fr.formation.bibliotheque.model;

import java.time.LocalDate;

public class Livre {

	private int id;
	private String titre;
	private String auteur;
	private int nbPages;
	private LocalDate dateAchat;
	private String isbn;

	public Livre(String titre, String auteur, int nbPages, LocalDate dateAchat, String isbn) {
		this.titre = titre;
		this.auteur = auteur;
		this.nbPages = nbPages;
		this.dateAchat = dateAchat;
		this.isbn = isbn;
	}

	public Livre(int id, String titre, String auteur, int nbPages, LocalDate dateAchat, String isbn) {
		this.id = id;
		this.titre = titre;
		this.auteur = auteur;
		this.nbPages = nbPages;
		this.dateAchat = dateAchat;
		this.isbn = isbn;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public String getAuteur() {
		return auteur;
	}

	public void setAuteur(String auteur) {
		this.auteur = auteur;
	}

	public int getNbPages() {
		return nbPages;
	}

	public void setNbPages(int nbPages) {
		this.nbPages = nbPages;
	}

	public LocalDate getDateAchat() {
		return dateAchat;
	}

	public void setDateAchat(LocalDate dateAchat) {
		this.dateAchat = dateAchat;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	@Override
	public String toString() {
		return "Livre [id=" + id + ", titre=" + titre + ", auteur=" + auteur + ", nbPages=" + nbPages + ", dateAchat="
				+ dateAchat + ", isbn=" + isbn + "]";
	}

}
