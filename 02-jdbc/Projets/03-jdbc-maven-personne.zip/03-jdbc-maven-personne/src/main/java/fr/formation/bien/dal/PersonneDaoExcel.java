package fr.formation.bien.dal;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import fr.formation.bien.exception.PersonneException;
import fr.formation.bien.model.Personne;

public class PersonneDaoExcel implements PersonneDao {

	@Override
	public List<Personne> findAll() throws PersonneException {
		List<Personne> maListe = new ArrayList<Personne>();
		
		
		return maListe;
	}
	
	@Override
	public Optional<Personne> findById(int id) throws PersonneException {
		return null;
	}
	
	@Override
	public void add(Personne p) throws PersonneException{
		
	}

	
	
}
