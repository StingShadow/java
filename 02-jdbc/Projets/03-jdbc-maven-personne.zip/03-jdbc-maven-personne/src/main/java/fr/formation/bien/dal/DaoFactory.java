package fr.formation.bien.dal;

public class DaoFactory {

	
	public static PersonneDao getPersonneDao() {
		return new PersonneDaoJson();
	}
}
