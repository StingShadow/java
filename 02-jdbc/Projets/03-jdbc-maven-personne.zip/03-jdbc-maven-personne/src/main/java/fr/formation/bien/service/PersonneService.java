package fr.formation.bien.service;

import java.util.List;

import fr.formation.bien.dal.DaoFactory;
import fr.formation.bien.dal.PersonneDao;
import fr.formation.bien.exception.PersonneException;
import fr.formation.bien.model.Personne;

public class PersonneService {

	private PersonneDao pDao;
	
	public PersonneService() {
		pDao = DaoFactory.getPersonneDao();
				
	}
	
	public void ajouterPersonne(Personne p) throws PersonneException {
		// gestion des regles m�tiers
		if (p == null)
			throw new PersonneException("La personne � ajouter ne doit pas �tre nul");
		if (p.getNom() == null || p.getNom().isBlank())
			throw new PersonneException("Le nom doit comporter au moins un caractere");
	
		pDao.add(p);
		
	}
	
	
	public List<Personne> recupererTouteslesPersonnes() throws PersonneException{
		return pDao.findAll();
	}
}
