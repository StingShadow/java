package fr.formation.bien.ihm;

import java.util.List;

import fr.formation.bien.dal.DaoUtil;
import fr.formation.bien.exception.PersonneException;
import fr.formation.bien.model.Personne;
import fr.formation.bien.service.PersonneService;

public class MonProgramme {
	public static void main(String[] args) {
		PersonneService ps = new PersonneService();
		
		afficherToutesLesPersonnes(ps);
		
		Personne personnePasOK = new Personne(null, "Joe", 30);
		try {
			ps.ajouterPersonne(personnePasOK);
		} catch (PersonneException e) {
			System.out.println(e.getMessage());
		}
		afficherToutesLesPersonnes(ps);

		Personne personneOK = new Personne("bleuCiel", "Jack", 44);
		try {
			ps.ajouterPersonne(personneOK);
		} catch (PersonneException e) {
			System.out.println(e.getMessage());
		}
		afficherToutesLesPersonnes(ps);
		
		
		DaoUtil.close();
	}

	private static void afficherToutesLesPersonnes(PersonneService ps) {
		System.out.println("Liste des personnes : ");
		try {
			List<Personne> listeS = ps.recupererTouteslesPersonnes();
			for (Personne personne : listeS) {
				System.out.println("   - " + personne);
			}
		} catch (PersonneException e) {
			System.out.println(e.getMessage());
		}
	}
}
