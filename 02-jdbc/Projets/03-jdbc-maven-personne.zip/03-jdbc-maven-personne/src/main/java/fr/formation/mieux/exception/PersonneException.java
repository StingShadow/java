package fr.formation.mieux.exception;

public class PersonneException extends Exception{

	public PersonneException(String message) {
		super(message);
	}
}
