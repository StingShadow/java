package fr.formation.pasbien;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class TestJDBC {

	private static final String DRIVER = "org.h2.Driver";
	private static final String URL = "jdbc:h2:~/formation";
	private static final String LOGIN = "form";
	private static final String PASSWD = "ation";
	
	private static final String SELECTALL = "Select id, nom, prenom, age FROM personne";
	private static final String SELECTONE = "Select id, nom, prenom, age FROM personne where id = ?";
	private static final String INSERT = "INSERT INTO personne (nom, prenom, age) values(?, ?, ?)";
	private static final String INSERTAVECID = "INSERT INTO personne (nom, prenom, age, id) values(?, ?, ?, ?)";
	private static final String UPDATE = "UPDATE personne SET nom = ?, prenom = ?, age = ? WHERE id = ?";
	private static final String DELETEALL = "DELETE FROM personne";
	
	public static void main(String[] args) {

		try {
			Class.forName(DRIVER);
			Connection conn = DriverManager.getConnection(URL, LOGIN, PASSWD);
			System.out.println("Connexion effectu�e");
			
			// SUPPRESSION DE TOUTES LES PERSONNES
			Statement stt1 = conn.createStatement();
			stt1.executeUpdate(DELETEALL);
			stt1.close();
			
			// ENREGISTREMENT DE TROIS PERSONNES
			
			PreparedStatement pstt = conn.prepareStatement(INSERT);
			pstt.setString(1, "Lejaune");
			pstt.setString(2, "Lucille");
			pstt.setInt(3, 54);
			int res = pstt.executeUpdate();
			System.out.println("Nb lignes impact�e(s) par insert : " + res);

			pstt.setString(1, "Lebleu");
			pstt.setString(2, "Henri");
			pstt.setInt(3, 69);
			res = pstt.executeUpdate();
			System.out.println("Nb lignes impact�e(s) par insert : " + res);

			pstt.setString(1, "Levert");
			pstt.setString(2, "Sergio");
			pstt.setInt(3, 34);
			res = pstt.executeUpdate();
			System.out.println("Nb lignes impact�e(s) par insert : " + res);

			pstt.close();
			
			// AFFICHAGE DE LA LISTE DES PERSONNES EN BASE
			
			Statement stt = conn.createStatement();
			ResultSet rs = stt.executeQuery(SELECTALL);
			
			System.out.println("Liste des personnes en base : ");
			while(rs.next()) {
				long id = rs.getLong("id");
				String nom = rs.getString(2);
				String prenom = rs.getString("prenom");
				int age = rs.getInt(4);
				System.out.println("   - " + id + " : " + prenom + " " + nom + " (" + age + " ans)");
			}
			
			rs.close();
			stt.close();
			
			// DEMANDER A L'UTILISATEUR L'ID DE LA PERSONNE A AFFICHER ET L'AFFICHER
			
			Scanner sc = new Scanner(System.in);
			System.out.println("Id de la personne � rechercher : ");
			int id = sc.nextInt();
			PreparedStatement pstt1 = conn.prepareStatement(SELECTONE);
			pstt1.setInt(1, id);
			ResultSet rs1 = pstt1.executeQuery();
			if(rs1.next()) {
				long cle = rs1.getLong("id");
				String nom = rs1.getString(2);
				String prenom = rs1.getString("prenom");
				int age = rs1.getInt(4);
				System.out.println("Personne trouv�e : " + cle + " : " + prenom + " " + nom + " (" + age + " ans)");
			
			
				// UPDATE DE LA PERSONNE
				PreparedStatement pstt2 = conn.prepareStatement(UPDATE);
				pstt2.setString(1, "Lataupe");
				pstt2.setString(2, "Ren�");
				pstt2.setInt(3, 3);
				pstt2.setInt(4, id);
				pstt2.executeUpdate();
			
				pstt2.close();
			}
			else {
				System.out.println("Aucune personne trouv�e avec cet id");
			}
			rs1.close();
			pstt1.close();
			
			
			stt = conn.createStatement();
			rs = stt.executeQuery(SELECTALL);
			
			System.out.println("Liste des personnes en base apres modification : ");
			while(rs.next()) {
				long id1 = rs.getLong("id");
				String nom = rs.getString(2);
				String prenom = rs.getString("prenom");
				int age = rs.getInt(4);
				System.out.println("   - " + id1 + " : " + prenom + " " + nom + " (" + age + " ans)");
			}
			
			rs.close();
			stt.close();
			
			// NOTION TRANSACTIONNELLE
			conn.setAutoCommit(false);
			
			try {
				PreparedStatement psttTrans = conn.prepareStatement(INSERT);
				psttTrans.setString(1, "Lerouge");
				psttTrans.setString(2, "Lili");
				psttTrans.setInt(3, 32);
				psttTrans.executeUpdate();
				
				PreparedStatement psttTrans2 = conn.prepareStatement(INSERTAVECID);

				psttTrans2.setString(1, "Lerouge2");
				psttTrans2.setString(2, "Lili2");
				psttTrans2.setInt(3, 322);
				psttTrans2.setInt(4, 92);
				psttTrans2.executeUpdate();
				
				conn.commit();
			} catch (Exception e) {
				conn.rollback();
				e.printStackTrace();
			}
			
			stt = conn.createStatement();
			rs = stt.executeQuery(SELECTALL);
			
			System.out.println("Liste des personnes en base apres transaction : ");
			while(rs.next()) {
				long id1 = rs.getLong("id");
				String nom = rs.getString(2);
				String prenom = rs.getString("prenom");
				int age = rs.getInt(4);
				System.out.println("   - " + id1 + " : " + prenom + " " + nom + " (" + age + " ans)");
			}
			
			rs.close();
			stt.close();
			
			
			sc.close();
			conn.close();
		} catch (ClassNotFoundException e) {
			System.out.println("Driver non trouv�");
		} catch (SQLException e) {
			System.out.println("Connexion non effectu�e : " + e.getMessage());
		}
		
		
		
		
		
		
		System.out.println("Fin du programme");
	}

}
