package fr.formation.pasbien;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestJDBC {

	private static final String DRIVER = "org.h2.Driver";
	private static final String URL = "jdbc:h2:~/formation";
	private static final String LOGIN = "form";
	private static final String PASSWD = "ation";
	private static final String SELECTALL = "Select id, nom, prenom, age FROM personne";
	private static final String INSERT = "INSERT INTO personne (nom, prenom, age) values(?, ?, ?)";
	
	public static void main(String[] args) {

		try {
			Class.forName(DRIVER);
			Connection conn = DriverManager.getConnection(URL, LOGIN, PASSWD);
			System.out.println("Connexion effectu�e");
			
			// SUPPRESSION DE TOUTES LES PERSSONES
			
			// ENREGISTREMENT DE TROIS PERSONNES
			
			PreparedStatement pstt = conn.prepareStatement(INSERT);
			pstt.setString(1, "Lejaune");
			pstt.setString(2, "Lucille");
			pstt.setInt(3, 54);
			int res = pstt.executeUpdate();
			System.out.println("Nb lignes impact�e(s) par insert : " + res);

			pstt.setString(1, "Lebleu");
			pstt.setString(2, "Henri");
			pstt.setInt(3, 69);
			res = pstt.executeUpdate();
			System.out.println("Nb lignes impact�e(s) par insert : " + res);

			pstt.setString(1, "Levert");
			pstt.setString(2, "Sergio");
			pstt.setInt(3, 34);
			res = pstt.executeUpdate();
			System.out.println("Nb lignes impact�e(s) par insert : " + res);

			pstt.close();
			
			// AFFICHAGE DE LA LISTE DES PERSONNES EN BASE
			
			Statement stt = conn.createStatement();
			ResultSet rs = stt.executeQuery(SELECTALL);
			
			System.out.println("Liste des personnes en base : ");
			while(rs.next()) {
				long id = rs.getLong("id");
				String nom = rs.getString(2);
				String prenom = rs.getString("prenom");
				int age = rs.getInt(4);
				System.out.println("   - " + id + " : " + prenom + " " + nom + " (" + age + " ans)");
			}
			
			rs.close();
			stt.close();
			conn.close();
		} catch (ClassNotFoundException e) {
			System.out.println("Driver non trouv�");
		} catch (SQLException e) {
			System.out.println("Connexion non effectu�e : " + e.getMessage());
		}
		
		
		
		
		
		
		System.out.println("Fin du programme");
	}

}
