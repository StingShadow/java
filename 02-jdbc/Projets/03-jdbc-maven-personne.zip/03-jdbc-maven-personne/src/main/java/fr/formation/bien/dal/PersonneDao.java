package fr.formation.bien.dal;

import java.util.List;
import java.util.Optional;

import fr.formation.bien.exception.PersonneException;
import fr.formation.bien.model.Personne;

public interface PersonneDao {

	List<Personne> findAll() throws PersonneException;

	Optional<Personne> findById(int id) throws PersonneException;

	void add(Personne p) throws PersonneException;

}