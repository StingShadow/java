package fr.formation.mieux.dal;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import fr.formation.mieux.exception.PersonneException;
import fr.formation.mieux.model.Personne;

public class PersonneDao {
	
	private static final String SELECTALL = "Select id, nom, prenom, age FROM personne";
	private static final String SELECTONE = "Select id, nom, prenom, age FROM personne where id = ?";
	private static final String INSERT = "INSERT INTO personne (nom, prenom, age) values(?, ?, ?)";
	private static final String UPDATE = "UPDATE personne SET nom = ?, prenom = ?, age = ? WHERE id = ?";
	private static final String DELETEALL = "DELETE FROM personne";
	

	public List<Personne> findAll() throws PersonneException {
		List<Personne> maListe = new ArrayList<Personne>();
		try {
			Statement stt = DaoUtil.getConnection().createStatement();
			ResultSet rs = stt.executeQuery(SELECTALL);
			while(rs.next()) {
				int id = rs.getInt("id");
				String nom = rs.getString(2);
				String prenom = rs.getString("prenom");
				int age = rs.getInt(4);
				
				Personne p = new Personne(id, nom, prenom, age);
				maListe.add(p);
			}
		} catch (SQLException e) {
			throw new PersonneException("Probleme lors de l'appel � findAll : " + e.getMessage());
		}
		
		return maListe;
	}
	
}
