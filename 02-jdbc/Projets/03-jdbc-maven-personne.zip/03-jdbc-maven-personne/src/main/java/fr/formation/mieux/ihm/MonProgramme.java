package fr.formation.mieux.ihm;

import java.util.List;

import fr.formation.mieux.dal.DaoUtil;
import fr.formation.mieux.dal.PersonneDao;
import fr.formation.mieux.exception.PersonneException;
import fr.formation.mieux.model.Personne;

public class MonProgramme {
	public static void main(String[] args) {
		
		PersonneDao pDao = new PersonneDao();
		
		try {
			List<Personne> listeP = pDao.findAll();
			System.out.println("Liste des personnes :");
			for (Personne personne : listeP) {
				System.out.println("   - " + personne);
			}
			
		} catch (PersonneException e) {
			System.out.println(e.getMessage());
		}
		
		DaoUtil.close();
	}
}
