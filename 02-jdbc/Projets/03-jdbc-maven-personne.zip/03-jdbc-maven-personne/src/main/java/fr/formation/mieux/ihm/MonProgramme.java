package fr.formation.mieux.ihm;

import java.util.List;
import java.util.Optional;

import fr.formation.mieux.dal.DaoUtil;
import fr.formation.mieux.dal.PersonneDao;
import fr.formation.mieux.exception.PersonneException;
import fr.formation.mieux.model.Personne;

public class MonProgramme {
	public static void main(String[] args) {
		
		PersonneDao pDao = new PersonneDao();
		
		try {
			List<Personne> listeP = pDao.findAll();
			System.out.println("Liste des personnes :");
			for (Personne personne : listeP) {
				System.out.println("   - " + personne);
			}
			
		} catch (PersonneException e) {
			System.out.println(e.getMessage());
		}
		
		try {
			Optional<Personne> trouve68 = pDao.findById(68);
			if (trouve68.isPresent()) {
				Personne trouve = trouve68.get();
				System.out.println("trouve68 = " + trouve);
			}
			else {
				System.out.println("Pas de trouve68");
			}
			
			Optional<Personne> trouve12 = pDao.findById(12);
			System.out.println(trouve12.isPresent() ? "trouve 12 : " + trouve12.get() : "pas de trouve12");
			
		} catch (PersonneException e) {
			System.out.println(e.getMessage());
		}
		
		
		Personne nouveau = new Personne("Leorange", "Aline", 99);
		try {
			pDao.add(nouveau);
		} catch (PersonneException e) {
			System.out.println(e.getMessage());
		}
		
		try {
			List<Personne> listeP = pDao.findAll();
			System.out.println("Liste des personnes apres ajout :");
			for (Personne personne : listeP) {
				System.out.println("   - " + personne);
			}
			
		} catch (PersonneException e) {
			System.out.println(e.getMessage());
		}
		
		
		System.out.println("Le dernier enregistrement est " + nouveau);
		
		DaoUtil.close();
	}
}
