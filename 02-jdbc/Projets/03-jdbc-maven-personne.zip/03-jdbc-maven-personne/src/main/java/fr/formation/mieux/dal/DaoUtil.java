package fr.formation.mieux.dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DaoUtil {
//	private static final String DRIVER = "org.h2.Driver";
//	private static final String URL = "jdbc:h2:~/formation";
//	private static final String LOGIN = "form";
//	private static final String PASSWD = "ation";
	
//	private static final String DRIVER = "com.mysql.jdbc.Driver";
	private static final String URL = "jdbc:mysql://localhost:3306/formation";
	private static final String LOGIN = "root";
	private static final String PASSWD = "1234";
	
	private static Connection conn;
	
	public static Connection getConnection() {
		
		if (conn == null) {
			try {
//				Class.forName(DRIVER);
				conn = DriverManager.getConnection(URL, LOGIN, PASSWD);
			} catch (Exception e) {
				System.out.println("Connexion non effectu�e : " +e.getMessage());
				conn = null;
			} 
		}
		return conn;
	}
	
	
	public static void close() {
		try {
			conn.close();
		} catch (Exception e) {
			System.out.println("Probleme de fermeture de connexion : " +e.getMessage());
		}
		conn = null;
	}
}
